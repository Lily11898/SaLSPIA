# Data Directory

Bundled public-release files:

- `volcano_hires_surface_data`
- `maungawhau_hr.csv`

Some experiments require external curve data that are not bundled unless
redistribution permission has been confirmed:

- `cur_data deer`
- `s_loop_curve_data.txt`

Place authorized copies in this directory. See `../DATA_SOURCES.md`.
