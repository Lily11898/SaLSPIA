# Generated Results

Experiment drivers create CSV, MAT, PDF, PNG, and FIG outputs under this
directory as needed. Generated files are intentionally omitted from the public
source archive to keep the release compact and avoid stale benchmark timings.
