%% ========================================================================
%  run_ablation_curve.m
%  Ablation study for SaLSPIA curve fitting.
%
%  Compared variants:
%    1. BB1-LSPIA     : alpha_BB1 with the same GLL halving as SaLSPIA
%    2. BB2-LSPIA     : alpha_BB2 with the same GLL halving as SaLSPIA
%    3. Interp-only   : interpolated trial weight, no GLL halving
%    4. SaLSPIA       : interpolated trial weight with GLL halving
%  ========================================================================
clear; clc; close all;

script_dir = fileparts(mfilename('fullpath'));
repo_dir = fileparts(script_dir);
addpath(fullfile(repo_dir, 'algorithms'));
addpath(fullfile(repo_dir, 'utils'));

p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

params.c           = 1e-4;
params.M           = 10;
params.delta       = 1e-8;
params.p           = 3;
params.e_tol       = 1e-15;
params.max_halving = 100;

configs = {
    2, 10001, 2001;
    3,  1000,  288;
    7,   206,  101;
};

methods = {
    'BB1-LSPIA',   'bb1';
    'BB2-LSPIA',   'bb2';
    'Interp-only', 'interp-only';
    'SaLSPIA',     'salspia';
};

out_dir = fullfile(repo_dir, 'results', 'ablation_curve');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

results = cell(size(configs, 1), 1);
summary_rows = {};

for ic = 1:size(configs, 1)
    ex_id = configs{ic, 1};
    m1 = configs{ic, 2};
    n1 = configs{ic, 3};
    fprintf('\n=== Curve Example %d: m+1=%d, n+1=%d ===\n', ex_id, m1, n1);

    [Q, A, P0] = setup_curve_case(ex_id, m1, n1, p_deg);

    case_result.ex_id = ex_id;
    case_result.m1 = m1;
    case_result.n1 = n1;
    case_result.method = cell(size(methods, 1), 1);

    for im = 1:size(methods, 1)
        method_name = methods{im, 1};
        method_mode = methods{im, 2};
        run_params = params;
        run_params.mode = method_mode;

        fprintf('  %-12s ... ', method_name);
        [~, info] = ablation_lspia(A, Q, P0, tol_Ek, maxiter, run_params);
        fprintf('IT=%d  CPU=%.4fs  E=%.2e  halv=%d  status=%s\n', ...
            info.iter_count, info.cpu_time, info.Ek_history(end), ...
            info.total_halving, info.status);

        case_result.method{im}.name = method_name;
        case_result.method{im}.mode = method_mode;
        case_result.method{im}.info = info;

        summary_rows(end+1, :) = {sprintf('Curve Ex%d', ex_id), m1, n1, ...
            method_name, info.iter_count, info.cpu_time, info.Ek_history(end), ...
            info.err_history(end), info.total_halving, info.status}; %#ok<SAGROW>
    end

    results{ic} = case_result;
    plot_convergence(case_result, methods, tol_Ek, out_dir);
end

T = cell2table(summary_rows, 'VariableNames', ...
    {'Case', 'DataPoints', 'ControlPoints', 'Method', 'IT', 'CPU', ...
     'E_inf', 'FittingError', 'TotalHalving', 'Status'});
writetable(T, fullfile(out_dir, 'ablation_curve_summary.csv'));
write_latex_table(T, fullfile(out_dir, 'ablation_curve_table.tex'), 'Curve fitting ablation study.');
save(fullfile(out_dir, 'ablation_curve_results.mat'), ...
    'results', 'configs', 'methods', 'params', 'T');

disp(T);
fprintf('\nSaved curve ablation outputs to:\n  %s\n', out_dir);

%% ===== Helpers ==========================================================
function Q = generate_curve_data(ex_id, m1)
switch ex_id
    case 1
        theta = linspace(0, 2*pi, m1)';
        r = 2 + 4*cos(2*theta + pi/4) + cos(3*theta + pi/4);
        Q = [r.*cos(theta), r.*sin(theta)];
    case 2
        theta = linspace(0, 2*pi, m1)';
        Q = [10*cos(theta*pi/3), 10*sin(theta*pi/3), theta*pi/3];
    case 3
        fname = salspia_data('cur_data deer');
        if exist(fname, 'file')
            Q = load(fname);
            if m1 ~= size(Q, 1)
                idx = round(linspace(1, size(Q, 1), m1));
                Q = Q(idx, :);
            end
        else
            error(['Reindeer data file not found: %s\n' ...
                'See DATA_SOURCES.md before running Example 4.3.'], fname);
        end
    otherwise
        error('Unknown curve example id: %d', ex_id);
end
end

function [Q, A, P0] = setup_curve_case(ex_id, m1, n1, p_deg)
n = n1 - 1;
if ex_id == 7
    Q_full = load(salspia_data('s_loop_curve_data.txt'));
    [t_full, knots] = make_params_knots(Q_full, n, p_deg);
    keep = true(size(t_full));
    hole_centers = [0.15, 0.38, 0.62, 0.99];
    hole_half_width = 0.03;
    for ih = 1:numel(hole_centers)
        lo = hole_centers(ih) - hole_half_width;
        hi = hole_centers(ih) + hole_half_width;
        keep((t_full >= lo) & (t_full <= hi)) = false;
    end
    Q = Q_full(keep, :);
    assert(size(Q, 1) == m1, 'Unexpected Ex. 4.7 observed-point count.');
    A = build_collocation(knots, p_deg, t_full(keep));
    P0 = select_initial_ctrl_pts(Q_full, n);
else
    Q = generate_curve_data(ex_id, m1);
    [t, knots] = make_params_knots(Q, n, p_deg);
    A = build_collocation(knots, p_deg, t);
    P0 = select_initial_ctrl_pts(Q, n);
end
end

function plot_convergence(case_result, methods, tol_Ek, out_dir)
fig = figure('Name', sprintf('Curve Ex%d ablation', case_result.ex_id), ...
    'Color', 'w', 'Position', [100 100 760 520]);
styles = {'-o', '-s', '-^', '-d'};
colors = [0.00 0.45 0.74; 0.85 0.33 0.10; 0.49 0.18 0.56; 0.10 0.60 0.20];

hold on;
for im = 1:size(methods, 1)
    info = case_result.method{im}.info;
    y = max(info.Ek_history, realmin);
    mk = 1:max(1, floor(info.iter_count / 15)):info.iter_count + 1;
    semilogy(0:info.iter_count, y, styles{im}, ...
        'Color', colors(im, :), 'LineWidth', 1.4, 'MarkerSize', 4, ...
        'MarkerIndices', mk, 'DisplayName', case_result.method{im}.name);
end
yline(tol_Ek, '--', 'Color', [0.45 0.45 0.45], 'HandleVisibility', 'off');
hold off;
grid on;
xlabel('Iteration k');
ylabel('Relative gradient norm E_k');
title(sprintf('Curve Ex%d: ablation convergence', case_result.ex_id));
legend('Location', 'best');

base = fullfile(out_dir, sprintf('ablation_curve_ex%d_convergence', case_result.ex_id));
safe_export(fig, [base '.png']);
savefig(fig, [base '.fig']);
end

function write_latex_table(T, fname, caption_text)
fid = fopen(fname, 'w');
if fid == -1
    warning('Cannot write LaTeX table: %s', fname);
    return;
end
fprintf(fid, '\\begin{table}[t]\n');
fprintf(fid, '\\centering\n');
fprintf(fid, '\\caption{%s}\n', caption_text);
fprintf(fid, '\\begin{tabular}{llrrrr}\n');
fprintf(fid, '\\hline\n');
fprintf(fid, 'Case & Method & IT & CPU(s) & $E_\\infty$ & Halving \\\\\n');
fprintf(fid, '\\hline\n');
for i = 1:height(T)
    fprintf(fid, '%s & %s & %d & %.4f & %.2e & %d \\\\\n', ...
        T.Case{i}, T.Method{i}, T.IT(i), T.CPU(i), T.E_inf(i), T.TotalHalving(i));
end
fprintf(fid, '\\hline\n');
fprintf(fid, '\\end{tabular}\n');
fprintf(fid, '\\end{table}\n');
fclose(fid);
end

function safe_export(fig, fname)
try
    exportgraphics(fig, fname, 'Resolution', 300);
catch
    saveas(fig, fname);
end
end
