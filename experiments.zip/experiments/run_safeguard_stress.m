%% ========================================================================
%  run_safeguard_stress_rank_deficient.m
%  Stress ablation for the GLL halving safeguard.
%
%  This is not a replacement for the standard ablation table. It deliberately
%  scales the SaLSPIA trial weight by gamma > 1 to test whether the GLL
%  safeguard rejects overly aggressive trial steps.
%  ========================================================================
clear; clc; close all;

script_dir = fileparts(mfilename('fullpath'));
repo_dir = fileparts(script_dir);
addpath(fullfile(repo_dir, 'algorithms'));
addpath(fullfile(repo_dir, 'utils'));

p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

base_params.c           = 1e-4;
base_params.M           = 10;
base_params.delta       = 1e-8;
base_params.p           = 3;
base_params.e_tol       = 1e-15;
base_params.max_halving = 100;

% Use the same Missing G-loop case as in the standard ablation table.
% This makes the gamma=1 row consistent with the unscaled SaLSPIA result.
cs = setup_standard_gloop_case(p_deg, script_dir);

gamma_values = [1, 2, 4, 8];   % matches manuscript Table 9
methods = {
    'Scaled-Interp-only', 'interp-only';
    'Scaled-SaLSPIA',     'salspia';
};

out_dir = fullfile(repo_dir, 'results', 'safeguard_stress');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

fprintf('\n============================================================\n');
fprintf('Safeguard stress test: %s\n', cs.label);
fprintf('============================================================\n');
fprintf('  Data points: %d (removed %d), control points: %d, rank = %d\n', ...
    size(cs.Q, 1), size(cs.Q_missing, 1), cs.n + 1, cs.rankA);

summary_rows = {};
all_infos = cell(numel(gamma_values), size(methods, 1));

for ig = 1:numel(gamma_values)
    gamma = gamma_values(ig);
    fprintf('\n--- gamma = %.1f ---\n', gamma);

    for im = 1:size(methods, 1)
        method_name = methods{im, 1};
        method_mode = methods{im, 2};
        params = base_params;
        params.mode = method_mode;
        params.alpha_scale = gamma;

        fprintf('  %-18s ... ', method_name);
        [~, info] = ablation_lspia(cs.A, cs.Q, cs.P0, tol_Ek, maxiter, params);

        max_E = max(info.Ek_history(isfinite(info.Ek_history)));
        if isempty(max_E), max_E = NaN; end
        fprintf('IT=%d  E=%.2e  maxE=%.2e  halv=%d  status=%s\n', ...
            info.iter_count, info.Ek_history(end), max_E, ...
            info.total_halving, info.status);

        all_infos{ig, im} = info;
        summary_rows(end+1, :) = {cs.short_name, gamma, method_name, ...
            info.iter_count, info.cpu_time, info.Ek_history(end), max_E, ...
            info.err_history(end), info.total_halving, info.status}; %#ok<SAGROW>
    end
end

T = cell2table(summary_rows, 'VariableNames', ...
    {'Case', 'Gamma', 'Method', 'IT', 'CPU', 'E_inf', 'Max_E', ...
     'FittingError', 'TotalHalving', 'Status'});
writetable(T, fullfile(out_dir, 'safeguard_stress_summary.csv'));
save(fullfile(out_dir, 'safeguard_stress_results.mat'), ...
    'T', 'all_infos', 'gamma_values', 'methods', 'base_params', 'cs');

plot_stress_curves(all_infos, gamma_values, methods, tol_Ek, out_dir);
disp(T);
fprintf('\nSaved safeguard stress outputs to:\n  %s\n', out_dir);

%% ===== Helpers ==========================================================
function cs = setup_standard_gloop_case(p_deg, script_dir)
% Standard Ex 4.7 missing-data G-loop case used in the manuscript.
n = 100;
Q_full = load(salspia_data('s_loop_curve_data.txt'));
[t_full, knots] = make_params_knots(Q_full, n, p_deg);
[~, Q, Q_missing, t_keep] = remove_by_param_intervals( ...
    Q_full, t_full, [0.15, 0.38, 0.62, 0.99], 0.03);
A = build_collocation(knots, p_deg, t_keep);
P0 = select_initial_ctrl_pts(Q_full, n);

cs.label = 'Ex 4.7: G-loop scattered curve with four missing regions';
cs.short_name = 'Ex4_7_Gloop';
cs.Q = Q;
cs.Q_missing = Q_missing;
cs.A = A;
cs.P0 = P0;
cs.n = n;
cs.rankA = rank(A);
end

function [keep, Q_keep, Q_miss, t_keep] = remove_by_param_intervals( ...
    Q_full, t_full, hole_centers, hole_half_width)
keep = true(size(t_full));
for h = 1:length(hole_centers)
    lo = hole_centers(h) - hole_half_width;
    hi = hole_centers(h) + hole_half_width;
    keep((t_full >= lo) & (t_full <= hi)) = false;
end
Q_keep = Q_full(keep, :);
Q_miss = Q_full(~keep, :);
t_keep = t_full(keep);
end

function plot_stress_curves(all_infos, gamma_values, methods, tol_Ek, out_dir)
fig = figure('Name', 'Safeguard stress convergence', ...
    'Color', 'w', 'Position', [100 100 920 620]);
tiledlayout(2, 3, 'Padding', 'compact', 'TileSpacing', 'compact');

for ig = 1:numel(gamma_values)
    nexttile;
    hold on;
    for im = 1:size(methods, 1)
        info = all_infos{ig, im};
        y = info.Ek_history;
        y(~isfinite(y) | y <= 0) = realmin;
        if im == 1
            style = '-^';
            col = [0.49 0.18 0.56];
        else
            style = '-d';
            col = [0.10 0.60 0.20];
        end
        mk = 1:max(1, floor(info.iter_count / 12)):info.iter_count + 1;
        semilogy(0:info.iter_count, y, style, 'Color', col, ...
            'LineWidth', 1.3, 'MarkerSize', 4, 'MarkerIndices', mk, ...
            'DisplayName', methods{im, 1});
    end
    yline(tol_Ek, '--', 'Color', [0.45 0.45 0.45], 'HandleVisibility', 'off');
    hold off;
    grid on;
    title(sprintf('\\gamma = %.1f', gamma_values(ig)));
    xlabel('Iteration k');
    ylabel('E_k');
    legend('Location', 'best');
end

base = fullfile(out_dir, 'safeguard_stress_convergence');
safe_export(fig, [base '.png']);
savefig(fig, [base '.fig']);
end

function safe_export(fig, fname)
try
    exportgraphics(fig, fname, 'Resolution', 300);
catch
    saveas(fig, fname);
end
end
