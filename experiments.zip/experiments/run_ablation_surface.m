%% ========================================================================
%  run_ablation_surface.m
%  Ablation study for SaLSPIA tensor-product surface fitting.
%
%  Compared variants:
%    1. BB1-LSPIA
%    2. BB2-LSPIA
%    3. Interp-only
%    4. SaLSPIA
%  ========================================================================
clear; clc; close all;

script_dir = fileparts(mfilename('fullpath'));
repo_dir = fileparts(script_dir);
addpath(fullfile(repo_dir, 'algorithms'));
addpath(fullfile(repo_dir, 'utils'));

p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

params.c           = 1e-4;
params.M           = 10;
params.delta       = 1e-8;
params.p           = 3;
params.e_tol       = 1e-15;
params.max_halving = 100;

include_grid_data = false;  
configs = make_configs(include_grid_data);

methods = {
    'BB1-LSPIA',   'bb1';
    'BB2-LSPIA',   'bb2';
    'Interp-only', 'interp-only';
    'SaLSPIA',     'salspia';
};

out_dir = fullfile(repo_dir, 'results', 'ablation_surface');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

results = cell(numel(configs), 1);
summary_rows = {};

for ic = 1:numel(configs)
    cfg = configs(ic);
    fprintf('\n=== Surface %s: data=%dx%d, ctrl=%dx%d ===\n', ...
        cfg.name, cfg.m1u, cfg.m1v, cfg.n1u, cfg.n1v);

    [Qx, Qy, Qz, u_raw, v_raw] = generate_surface_data(cfg);
    u_par = normalize_param(u_raw);
    v_par = normalize_param(v_raw);

    knots_u = make_clamped_knots(cfg.n1u, p_deg);
    knots_v = make_clamped_knots(cfg.n1v, p_deg);
    Au = build_collocation(knots_u, p_deg, u_par);
    Av = build_collocation(knots_v, p_deg, v_par);

    Q_cell = {Qx, Qy, Qz};
    P0_cell = cell(3, 1);
    for j = 1:3
        P0_cell{j} = select_initial_surf(Q_cell{j}, cfg.n1u, cfg.n1v);
    end

    case_result.name = cfg.name;
    case_result.m1u = cfg.m1u;
    case_result.m1v = cfg.m1v;
    case_result.n1u = cfg.n1u;
    case_result.n1v = cfg.n1v;
    case_result.method = cell(size(methods, 1), 1);

    for im = 1:size(methods, 1)
        method_name = methods{im, 1};
        method_mode = methods{im, 2};
        run_params = params;
        run_params.mode = method_mode;

        fprintf('  %-12s ... ', method_name);
        [~, info] = ablation_lspia_surf(Au, Av, Q_cell, P0_cell, tol_Ek, maxiter, run_params);
        fprintf('IT=%d  CPU=%.4fs  E=%.2e  halv=%d  status=%s\n', ...
            info.iter_count, info.cpu_time, info.Ek_history(end), ...
            info.total_halving, info.status);

        case_result.method{im}.name = method_name;
        case_result.method{im}.mode = method_mode;
        case_result.method{im}.info = info;

        summary_rows(end+1, :) = {cfg.name, cfg.m1u, cfg.m1v, cfg.n1u, cfg.n1v, ...
            method_name, info.iter_count, info.cpu_time, info.Ek_history(end), ...
            info.err_history(end), info.total_halving, info.status}; %#ok<SAGROW>
    end

    results{ic} = case_result;
    plot_convergence(case_result, methods, tol_Ek, out_dir);
end

T = cell2table(summary_rows, 'VariableNames', ...
    {'Case', 'DataU', 'DataV', 'CtrlU', 'CtrlV', 'Method', 'IT', 'CPU', ...
     'E_inf', 'FittingError', 'TotalHalving', 'Status'});
writetable(T, fullfile(out_dir, 'ablation_surface_summary.csv'));
write_latex_table(T, fullfile(out_dir, 'ablation_surface_table.tex'), 'Surface fitting ablation study.');
save(fullfile(out_dir, 'ablation_surface_results.mat'), ...
    'results', 'configs', 'methods', 'params', 'T');

disp(T);
fprintf('\nSaved surface ablation outputs to:\n  %s\n', out_dir);

%% ===== Helpers ==========================================================
function configs = make_configs(include_grid_data)
% The first two cases match the manuscript's synthetic surface experiments.
% A third custom grid file is included only when surface_data is available.
configs = struct('name', {}, 'type', {}, 'm1u', {}, 'm1v', {}, 'n1u', {}, 'n1v', {});

configs(1).name = 'Dini';
configs(1).type = 'dini';
configs(1).m1u = 81;
configs(1).m1v = 81;
configs(1).n1u = 31;
configs(1).n1v = 31;

configs(2).name = 'Peaks';
configs(2).type = 'peaks';
configs(2).m1u = 121;
configs(2).m1v = 121;
configs(2).n1u = 41;
configs(2).n1v = 41;

surface_file = salspia_data('surface_data');
if include_grid_data && exist(surface_file, 'file')
    dims = read_surface_dims(surface_file);
    configs(3).name = 'GridData';
    configs(3).type = 'gridfile';
    configs(3).m1u = dims(1);
    configs(3).m1v = dims(2);
    configs(3).n1u = 65;
    configs(3).n1v = 65;
end
end

function [Qx, Qy, Qz, u_raw, v_raw] = generate_surface_data(cfg)
switch cfg.type
    case 'dini'
        th1 = linspace(0, 4*pi, cfg.m1u);
        th2 = linspace(0.1, pi - 0.1, cfg.m1v);
        [T1, T2] = meshgrid(th1, th2);
        T1 = T1';
        T2 = T2';
        Qx = cos(T1) .* sin(T2);
        Qy = sin(T1) .* sin(T2);
        Qz = cos(T2) + log(tan(T2 / 2)) + T1;
        u_raw = th1(:);
        v_raw = th2(:);

    case 'peaks'
        th1 = linspace(-3, 3, cfg.m1u);
        th2 = linspace(-4, 4, cfg.m1v);
        [T1, T2] = meshgrid(th1, th2);
        T1 = T1';
        T2 = T2';
        F = 3*(1 - T1).^2 .* exp(-T1.^2 - (T2 + 1).^2) ...
            - 10*(T1/5 - T1.^3 - T2.^5) .* exp(-T1.^2 - T2.^2) ...
            - (1/3) * exp(-(T1 + 1).^2 - T2.^2);
        Qx = T1;
        Qy = T2;
        Qz = F;
        u_raw = th1(:);
        v_raw = th2(:);

    case 'gridfile'
        surface_file = salspia_data('surface_data');
        [Qx, Qy, Qz] = load_grid_surface(surface_file);
        u_raw = linspace(0, 1, size(Qx, 1))';
        v_raw = linspace(0, 1, size(Qx, 2))';

    otherwise
        error('Unknown surface type: %s', cfg.type);
end
end

function u = normalize_param(u_raw)
u_raw = u_raw(:);
if abs(u_raw(end) - u_raw(1)) < eps
    u = linspace(0, 1, numel(u_raw))';
else
    u = (u_raw - u_raw(1)) / (u_raw(end) - u_raw(1));
end
end

function knots = make_clamped_knots(n1, p)
n = n1 - 1;
n_int = n - p;
knots = zeros(1, n1 + p + 1);
knots(1:p+1) = 0;
knots(end-p:end) = 1;
if n_int > 0
    internal = linspace(0, 1, n_int + 2);
    knots(p+2:end-p-1) = internal(2:end-1);
end
end

function P0 = select_initial_surf(Qc, n1u, n1v)
[mu1, mv1] = size(Qc);
idx_u = round(linspace(1, mu1, n1u));
idx_v = round(linspace(1, mv1, n1v));
P0 = Qc(idx_u, idx_v);
end

function dims = read_surface_dims(fname)
fid = fopen(fname, 'r');
if fid == -1
    error('Cannot open file: %s', fname);
end
line = fgetl(fid);
fclose(fid);
dims = sscanf(line, '%d %d');
if numel(dims) < 2
    error('Invalid surface_data header.');
end
end

function [Qx, Qy, Qz] = load_grid_surface(fname)
fid = fopen(fname, 'r');
if fid == -1
    error('Cannot open file: %s', fname);
end
dims = sscanf(fgetl(fid), '%d %d');
m1u = dims(1);
m1v = dims(2);
coords = zeros(m1u * m1v, 3);
idx = 0;
while ~feof(fid)
    line = fgetl(fid);
    if ischar(line) && startsWith(strtrim(line), 'v ')
        idx = idx + 1;
        vals = sscanf(line, 'v %f %f %f');
        coords(idx, :) = vals';
    end
end
fclose(fid);

if idx ~= m1u * m1v
    error('Expected %d vertices, read %d.', m1u * m1v, idx);
end

Qx = reshape(coords(:, 1), m1v, m1u)';
Qy = reshape(coords(:, 2), m1v, m1u)';
Qz = reshape(coords(:, 3), m1v, m1u)';
end

function plot_convergence(case_result, methods, tol_Ek, out_dir)
fig = figure('Name', sprintf('Surface %s ablation', case_result.name), ...
    'Color', 'w', 'Position', [100 100 760 520]);
styles = {'-o', '-s', '-^', '-d'};
colors = [0.00 0.45 0.74; 0.85 0.33 0.10; 0.49 0.18 0.56; 0.10 0.60 0.20];

hold on;
for im = 1:size(methods, 1)
    info = case_result.method{im}.info;
    y = max(info.Ek_history, realmin);
    mk = 1:max(1, floor(info.iter_count / 15)):info.iter_count + 1;
    semilogy(0:info.iter_count, y, styles{im}, ...
        'Color', colors(im, :), 'LineWidth', 1.4, 'MarkerSize', 4, ...
        'MarkerIndices', mk, 'DisplayName', case_result.method{im}.name);
end
yline(tol_Ek, '--', 'Color', [0.45 0.45 0.45], 'HandleVisibility', 'off');
hold off;
grid on;
xlabel('Iteration k');
ylabel('Relative gradient norm E_k');
title(sprintf('Surface %s: ablation convergence', case_result.name));
legend('Location', 'best');

safe_name = regexprep(case_result.name, '[^A-Za-z0-9]', '_');
base = fullfile(out_dir, sprintf('ablation_surface_%s_convergence', safe_name));
safe_export(fig, [base '.png']);
savefig(fig, [base '.fig']);
end

function write_latex_table(T, fname, caption_text)
fid = fopen(fname, 'w');
if fid == -1
    warning('Cannot write LaTeX table: %s', fname);
    return;
end
fprintf(fid, '\\begin{table}[t]\n');
fprintf(fid, '\\centering\n');
fprintf(fid, '\\caption{%s}\n', caption_text);
fprintf(fid, '\\begin{tabular}{llrrrr}\n');
fprintf(fid, '\\hline\n');
fprintf(fid, 'Case & Method & IT & CPU(s) & $E_\\infty$ & Halving \\\\\n');
fprintf(fid, '\\hline\n');
for i = 1:height(T)
    fprintf(fid, '%s & %s & %d & %.4f & %.2e & %d \\\\\n', ...
        T.Case{i}, T.Method{i}, T.IT(i), T.CPU(i), T.E_inf(i), T.TotalHalving(i));
end
fprintf(fid, '\\hline\n');
fprintf(fid, '\\end{tabular}\n');
fprintf(fid, '\\end{table}\n');
fclose(fid);
end

function safe_export(fig, fname)
try
    exportgraphics(fig, fname, 'Resolution', 300);
catch
    saveas(fig, fname);
end
end
