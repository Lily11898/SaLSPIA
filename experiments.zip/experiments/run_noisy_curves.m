%% ========================================================================
%  run_noisy_curves.m
%  Reproduce Table 6 and Figure 12: noisy full-rank curve fitting.
%
%  The noisy helix uses the same five-turn construction as the missing-data
%  experiment, with theta in [0, 30].
%
%  Full-rank comparison only:
%    LSPIA, ALSPIA, MLSPIA, SaLSPIA
%  ========================================================================
clear; clc; close all;

script_dir = fileparts(mfilename('fullpath'));
repo_dir = fileparts(script_dir);
addpath(fullfile(repo_dir, 'algorithms'));
addpath(fullfile(repo_dir, 'utils'));

out_dir = fullfile(repo_dir, 'results', 'table6_noisy_curves');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

params.c     = 1e-4;
params.M     = 10;
params.delta = 1e-8;

random_seed = 202608;
rng(random_seed, 'twister');

configs = {
    'Noisy_blob',  1, 480, 101, 0.75, 2*pi;
    'Noisy_helix', 2, 780, 201, 7.50, 30;
};

methods = {'LSPIA', 'ALSPIA', 'MLSPIA', 'SaLSPIA'};
summary_rows = {};
results = cell(size(configs, 1), 1);

fprintf('\n============================================================\n');
fprintf('Table 6: noisy full-rank curve fitting\n');
fprintf('Fixed sequential RNG stream: seed=%d, order=blob then helix.\n', random_seed);
fprintf('============================================================\n');

for ic = 1:size(configs, 1)
    short_name = configs{ic, 1};
    ex_id = configs{ic, 2};
    m1 = configs{ic, 3};
    n1 = configs{ic, 4};
    eta = configs{ic, 5};
    theta_max = configs{ic, 6};
    n = n1 - 1;

    Q_clean = generate_curve_data(ex_id, m1, theta_max);
    [Q_noisy, noise] = add_normalized_gaussian_noise(Q_clean, eta);
    perturbation_norm = norm(Q_noisy - Q_clean, 'fro');

    [t, knots] = make_params_knots(Q_noisy, n, p_deg);
    A = build_collocation(knots, p_deg, t);
    P0 = select_initial_ctrl_pts(Q_noisy, n);
    rankA = rank(A);
    assert(rankA == n1, '%s must be full-rank for the Table 6 comparison.', short_name);

    fprintf('\n%s: data=%d, control=%d, eta=%.2f, theta_max=%.12g, seed=%d, stream_index=%d, rank=%d\n', ...
        short_name, m1, n1, eta, theta_max, random_seed, ic, rankA);
    fprintf('  ||Q_noisy-Q||_F = %.12f\n', perturbation_norm);

    [P_ls, info_ls] = lspia(A, Q_noisy, P0, tol_Ek, maxiter);
    print_method('LSPIA', info_ls);
    [P_al, info_al] = alspia(A, Q_noisy, P0, tol_Ek, maxiter);
    print_method('ALSPIA', info_al);
    [P_ml, info_ml] = mlspia(A, Q_noisy, P0, tol_Ek, maxiter);
    print_method('MLSPIA', info_ml);
    [P_sl, info_sl] = salspia(A, Q_noisy, P0, tol_Ek, maxiter, params);
    print_method('SaLSPIA', info_sl);

    infos = {info_ls, info_al, info_ml, info_sl};
    Ps = {P_ls, P_al, P_ml, P_sl};
    for im = 1:numel(methods)
        info = infos{im};
        summary_rows(end+1, :) = {short_name, m1, n1, eta, theta_max, ...
            random_seed, ic, perturbation_norm, rankA, methods{im}, ...
            info.iter_count, info.cpu_time, info.Ek_history(end), ...
            info.err_history(end)}; %#ok<SAGROW>
    end

    result.short_name = short_name;
    result.ex_id = ex_id;
    result.m1 = m1;
    result.n1 = n1;
    result.eta = eta;
    result.theta_max = theta_max;
    result.random_seed = random_seed;
    result.stream_index = ic;
    result.Q_clean = Q_clean;
    result.Q_noisy = Q_noisy;
    result.noise = noise;
    result.knots = knots;
    result.P0 = P0;
    result.Ps = Ps;
    result.infos = infos;
    results{ic} = result;
end

T = cell2table(summary_rows, 'VariableNames', ...
    {'Case', 'DataPoints', 'ControlPoints', 'Eta', 'ThetaMax', 'RandomSeed', ...
     'StreamIndex', 'PerturbationNorm', 'Rank', 'Method', 'IT', 'CPU', 'E_inf', ...
     'FittingError'});
writetable(T, fullfile(out_dir, 'table6_noisy_curves_summary.csv'));
save(fullfile(out_dir, 'table6_noisy_curves_results.mat'), ...
    'T', 'results', 'configs', 'methods', 'params', ...
    'tol_Ek', 'maxiter');
write_latex_table(T, fullfile(out_dir, 'table6_noisy_curves.tex'));
plot_figure12(results{1}, p_deg, out_dir);
plot_convergence(results, methods, tol_Ek, out_dir);

disp(T);
fprintf('\nSaved Table 6 and Figure 12 outputs to:\n  %s\n', out_dir);

%% ===== Data setup =======================================================
function Q = generate_curve_data(ex_id, m1, theta_max)
theta = linspace(0, theta_max, m1)';
switch ex_id
    case 1
        r = 2 + 4*cos(2*theta + pi/4) + cos(3*theta + pi/4);
        Q = [r .* cos(theta), r .* sin(theta)];
    case 2
        Q = [10*cos(theta*pi/3), 10*sin(theta*pi/3), theta*pi/3];
    otherwise
        error('Unknown noisy curve example id: %d', ex_id);
end
end

function [Q_noisy, noise] = add_normalized_gaussian_noise(Q, eta)
noise = randn(size(Q));
noise = eta * noise / norm(noise, 'fro');
Q_noisy = Q + noise;
end

%% ===== Output helpers ===================================================
function print_method(name, info)
fprintf('  %-8s IT=%-3d E=%.2e CPU=%.4fs\n', ...
    name, info.iter_count, info.Ek_history(end), info.cpu_time);
end

function plot_figure12(blob_result, p_deg, out_dir)
t_plot = linspace(0, 1, 2001);
A_plot = build_collocation(blob_result.knots, p_deg, t_plot);
P_salspia = blob_result.Ps{4};
C = A_plot * P_salspia;

fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 1000 430]);
subplot(1, 2, 1);
plot(blob_result.Q_noisy(:, 1), blob_result.Q_noisy(:, 2), '.', ...
    'Color', [0.20 0.45 0.75], 'MarkerSize', 8);
axis equal;
grid on;
xlabel('x');
ylabel('y');
title('(a) Noisy blob data');

subplot(1, 2, 2);
plot(blob_result.Q_noisy(:, 1), blob_result.Q_noisy(:, 2), '.', ...
    'Color', [0.70 0.70 0.70], 'MarkerSize', 6);
hold on;
plot(C(:, 1), C(:, 2), '-', 'Color', [0.85 0.33 0.10], ...
    'LineWidth', 1.8);
hold off;
axis equal;
grid on;
xlabel('x');
ylabel('y');
title('(b) SaLSPIA fitting curve');
legend({'Noisy data', 'SaLSPIA fit'}, 'Location', 'best');

safe_export(fig, fullfile(out_dir, 'fig12_noisy_blob_fit.png'));
try
    exportgraphics(fig, fullfile(out_dir, 'fig12_noisy_blob_fit.pdf'), ...
        'ContentType', 'vector');
catch
    print(fig, fullfile(out_dir, 'fig12_noisy_blob_fit.pdf'), '-dpdf', '-bestfit');
end
close(fig);
end

function plot_convergence(results, methods, tol_Ek, out_dir)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 1000 430]);
styles = {'-o', '-s', '-d', '-p'};
colors = [0.00 0.45 0.74; 0.75 0.00 0.00; 0.49 0.18 0.56; 0.85 0.33 0.10];
for ic = 1:numel(results)
    subplot(1, numel(results), ic);
    hold on;
    for im = 1:numel(methods)
        info = results{ic}.infos{im};
        mk = 1:max(1, floor(info.iter_count / 12)):info.iter_count + 1;
        semilogy(0:info.iter_count, max(info.Ek_history, realmin), ...
            styles{im}, 'Color', colors(im, :), 'LineWidth', 1.3, ...
            'MarkerSize', 4, 'MarkerIndices', mk, ...
            'DisplayName', methods{im});
    end
    yline(tol_Ek, '--', 'Color', [0.45 0.45 0.45], ...
        'HandleVisibility', 'off');
    hold off;
    grid on;
    xlabel('Iteration k');
    ylabel('Relative gradient norm E_k');
    title(strrep(results{ic}.short_name, '_', ' '));
    legend('Location', 'best');
end
safe_export(fig, fullfile(out_dir, 'table6_noisy_curves_convergence.png'));
close(fig);
end

function write_latex_table(T, fname)
fid = fopen(fname, 'w');
if fid == -1
    warning('Cannot write LaTeX table: %s', fname);
    return;
end
fprintf(fid, '\\begin{table}[t]\n');
fprintf(fid, '\\centering\n');
fprintf(fid, '\\caption{Numerical results for noisy full-rank curve fitting.}\n');
fprintf(fid, '\\begin{tabular}{llrrrr}\n');
fprintf(fid, '\\hline\n');
fprintf(fid, 'Case & Method & IT & CPU(s) & $E_\\infty$ & $\\|AP-Q\\|_F^2$ \\\\\n');
fprintf(fid, '\\hline\n');
for i = 1:height(T)
    fprintf(fid, '%s & %s & %d & %.4f & %.2e & %.2e \\\\\n', ...
        strrep(T.Case{i}, '_', ' '), T.Method{i}, T.IT(i), T.CPU(i), ...
        T.E_inf(i), T.FittingError(i));
end
fprintf(fid, '\\hline\n');
fprintf(fid, '\\end{tabular}\n');
fprintf(fid, '\\end{table}\n');
fclose(fid);
end

function safe_export(fig, fname)
try
    exportgraphics(fig, fname, 'Resolution', 300);
catch
    saveas(fig, fname);
end
end