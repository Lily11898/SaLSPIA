%% ========================================================================
%  plot_conv_curve_ex41.m
%  收敛曲线代表图 -- 曲线拟合 Example 4.1 (blob)
%  纵轴: 相对梯度范数 E_k (log10);  横轴: 迭代次数 k
%  对比方法: LSPIA, ALSPIA, MLSPIA, SaLSPIA
%
%  依赖独立函数(同目录下的函数文件):
%    make_params_knots.m, build_collocation.m, select_initial_ctrl_pts.m,
%    lspia.m, alspia.m, mlspia.m, salspia.m
%  ========================================================================
clear; clc; close all;
%% ---- 参数 ----
p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;
salspia_params.c = 1e-4;     % sigma
salspia_params.M = 10;       % GLL memory length
salspia_params.delta = 1e-8;
%% ---- Example 4.1: blob curve ----
m1 = 15001;  n1 = 3001;  n = n1 - 1;
theta = linspace(0, 2*pi, m1)';
r = 2 + 4*cos(2*theta + pi/4) + cos(3*theta + pi/4);
Q = [r.*cos(theta), r.*sin(theta)];
[t, knots] = make_params_knots(Q, n, p_deg);
A  = build_collocation(knots, p_deg, t);
P0 = select_initial_ctrl_pts(Q, n);
eigvals = sort(real(eig(A'*A)));
eigvals = eigvals(eigvals > 1e-14);
kappa   = eigvals(end)/eigvals(1);
%% ---- 运行四个方法 ----
[~, info_ls] = lspia (A, Q, P0, tol_Ek, maxiter);
[~, info_al] = alspia(A, Q, P0, tol_Ek, maxiter);
[~, info_ml] = mlspia(A, Q, P0, tol_Ek, maxiter);
[~, info_sl] = salspia(A, Q, P0, tol_Ek, maxiter, salspia_params);
fprintf('LSPIA  IT=%d\nALSPIA IT=%d\nMLSPIA IT=%d\nSaLSPIA IT=%d\n', ...
    info_ls.iter_count, info_al.iter_count, info_ml.iter_count, info_sl.iter_count);
%% ---- 绘图 ----
fig = figure('Position',[100 100 640 470],'Color','w');
ax  = axes('Parent',fig); hold(ax,'on');
% 颜色(黑白打印也可区分: 不同颜色 + 不同标记 + 空心)
col_ls = [0.12 0.31 0.47];   % 深蓝
col_al = [0.75 0.00 0.00];   % 红
col_ml = [0.44 0.19 0.63];   % 紫
col_sl = [0.85 0.33 0.10];   % 橙
% 标记抽稀(每条线约 14 个标记)
mk = @(it) unique([1:max(1,floor(it/14)):it+1, it+1]);
semilogy(ax, 0:info_ls.iter_count, info_ls.Ek_history, '-o', ...
'Color',col_ls,'MarkerSize',5,'LineWidth',1.2, ...
'MarkerFaceColor','w','MarkerIndices',mk(info_ls.iter_count),'DisplayName','LSPIA');
semilogy(ax, 0:info_al.iter_count, info_al.Ek_history, '-s', ...
'Color',col_al,'MarkerSize',5,'LineWidth',1.2, ...
'MarkerFaceColor','w','MarkerIndices',mk(info_al.iter_count),'DisplayName','ALSPIA');
semilogy(ax, 0:info_ml.iter_count, info_ml.Ek_history, '-d', ...
'Color',col_ml,'MarkerSize',5,'LineWidth',1.2, ...
'MarkerFaceColor','w','MarkerIndices',mk(info_ml.iter_count),'DisplayName','MLSPIA');
semilogy(ax, 0:info_sl.iter_count, info_sl.Ek_history, '-p', ...
'Color',col_sl,'MarkerSize',6,'LineWidth',1.7, ...
'MarkerFaceColor','w','MarkerIndices',mk(info_sl.iter_count),'DisplayName','SaLSPIA');
% 收敛阈值参考线
yline(ax, tol_Ek, '--', 'Color',[.5 .5 .5], 'LineWidth',0.9, 'HandleVisibility','off');
text(ax, info_ls.iter_count*0.98, tol_Ek*1.5, 'tol = 10^{-6}', ...
'Color',[.4 .4 .4],'FontSize',9,'HorizontalAlignment','right');
set(ax,'YScale','log');
xlabel(ax,'Iteration $k$','Interpreter','latex','FontSize',12);
ylabel(ax,'Relative gradient norm $E_k$','Interpreter','latex','FontSize',12);
title(ax, sprintf('Curve fitting (Example 4.1, blob): $m{+}1{=}%d$, $n{+}1{=}%d$', m1, n1), ...
'Interpreter','latex','FontSize',12);
legend(ax,'Location','northeast','FontSize',10);
grid(ax,'on'); box(ax,'on');
set(ax,'FontSize',11,'GridLineStyle',':','XLim',[0 info_ls.iter_count],'Layer','top');
%% ---- 导出(投稿用矢量 + 预览) ----
print(fig,'fig_conv_curve_ex41','-dpdf','-r300','-bestfit');
print(fig,'fig_conv_curve_ex41','-dpng','-r300');
fprintf('saved: fig_conv_curve_ex41.pdf / .png\n');
