%% ========================================================================
%  run_curve_comparison.m
%  Curve fitting comparison (paper Table 2, Examples 4.1-4.3):
%      LSPIA  vs  ALSPIA  vs  MLSPIA  vs  SaLSPIA
%
%  SaLSPIA = salspia.m  (spectral-adaptive LSPIA, the proposed method).
%  Run setup_paths.m once before this script.
%  ========================================================================
clear; clc; close all;

%% ===== Settings =========================================================
p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

salspia_params.c     = 1e-4;   % GLL sufficient-decrease (sigma)
salspia_params.M     = 10;     % GLL memory length
salspia_params.delta = 1e-8;   % truncation threshold (eq 8)

% (example_id, m+1, n+1)
configs = {
    1, 15001, 3001;
    2, 10001, 2001;
    3,  1000,  288;
};

%% ===== Run ==============================================================
n_cfg   = size(configs, 1);
results = cell(n_cfg, 1);

for ic = 1:n_cfg
    ex_id = configs{ic,1};  m1 = configs{ic,2};  n1 = configs{ic,3};
    m = m1-1;  n = n1-1;

    fprintf('\n=== Example %d:  m+1=%d,  n+1=%d ===\n', ex_id, m1, n1);

    Q           = generate_curve_data(ex_id, m1);
    [t, knots]  = make_params_knots(Q, n, p_deg);
    A           = build_collocation(knots, p_deg, t);
    P0          = select_initial_ctrl_pts(Q, n);

    eigvals = sort(real(eig(A'*A)));
    eigvals = eigvals(eigvals > 1e-14);
    kappa   = eigvals(end)/eigvals(1);
    fprintf('  kappa = %.2e\n', kappa);

    fprintf('  LSPIA      ... ');
    [~, info_ls] = lspia(A, Q, P0, tol_Ek, maxiter);
    fprintf('IT=%d  CPU=%.4fs  E=%.2e\n', info_ls.iter_count, info_ls.cpu_time, info_ls.Ek_history(end));

    fprintf('  ALSPIA     ... ');
    [~, info_al] = alspia(A, Q, P0, tol_Ek, maxiter);
    fprintf('IT=%d  CPU=%.4fs  E=%.2e\n', info_al.iter_count, info_al.cpu_time, info_al.Ek_history(end));

    fprintf('  MLSPIA     ... ');
    [~, info_ml] = mlspia(A, Q, P0, tol_Ek, maxiter);
    fprintf('IT=%d  CPU=%.4fs  E=%.2e  (omega=%.4f, nu=%.4f)\n', ...
        info_ml.iter_count, info_ml.cpu_time, info_ml.Ek_history(end), info_ml.omega, info_ml.nu);

    fprintf('  SaLSPIA    ... ');
    [~, info_sl] = salspia(A, Q, P0, tol_Ek, maxiter, salspia_params);
    fprintf('IT=%d  CPU=%.4fs  E=%.2e\n', info_sl.iter_count, info_sl.cpu_time, info_sl.Ek_history(end));

    res.ex_id=ex_id; res.m1=m1; res.n1=n1; res.kappa=kappa;
    res.info_ls=info_ls; res.info_al=info_al; res.info_ml=info_ml; res.info_sl=info_sl;
    results{ic} = res;

    %% Plot
    figure('Name',sprintf('Curve Ex%d (m=%d,n=%d)',ex_id,m,n),'Position',[100 100 1200 450]);
    subplot(1,2,1);
    mk_ls = 1:max(1,floor(info_ls.iter_count/15)):info_ls.iter_count+1;
    mk_al = 1:max(1,floor(info_al.iter_count/12)):info_al.iter_count+1;
    mk_ml = 1:max(1,floor(info_ml.iter_count/12)):info_ml.iter_count+1;
    mk_sl = 1:max(1,floor(info_sl.iter_count/12)):info_sl.iter_count+1;

    semilogy(0:info_ls.iter_count, info_ls.Ek_history,'b-o','MarkerSize',3,'DisplayName','LSPIA','MarkerIndices',mk_ls);
    hold on;
    semilogy(0:info_al.iter_count, info_al.Ek_history,'r-s','MarkerSize',4,'DisplayName','ALSPIA','MarkerIndices',mk_al);
    semilogy(0:info_ml.iter_count, info_ml.Ek_history,'m-d','MarkerSize',4,'DisplayName','MLSPIA','MarkerIndices',mk_ml);
    semilogy(0:info_sl.iter_count, info_sl.Ek_history,'-p','Color',[0.85 0.33 0.10],'MarkerSize',5,'LineWidth',1.4,'DisplayName','SaLSPIA','MarkerIndices',mk_sl);
    hold off;
    yline(tol_Ek,'--','Color',[.5 .5 .5],'HandleVisibility','off');
    xlabel('Iteration k'); ylabel('E_k');
    title(sprintf('Ex %d: m+1=%d, n+1=%d  (\\kappa=%.1e)',ex_id,m1,n1,kappa));
    legend('Location','best'); grid on;

    subplot(1,2,2);
    semilogy(0:info_ls.iter_count, info_ls.err_history,'b-o','MarkerSize',3,'DisplayName','LSPIA','MarkerIndices',mk_ls);
    hold on;
    semilogy(0:info_al.iter_count, info_al.err_history,'r-s','MarkerSize',4,'DisplayName','ALSPIA','MarkerIndices',mk_al);
    semilogy(0:info_ml.iter_count, info_ml.err_history,'m-d','MarkerSize',4,'DisplayName','MLSPIA','MarkerIndices',mk_ml);
    semilogy(0:info_sl.iter_count, info_sl.err_history,'-p','Color',[0.85 0.33 0.10],'MarkerSize',5,'LineWidth',1.4,'DisplayName','SaLSPIA','MarkerIndices',mk_sl);
    hold off;
    xlabel('Iteration k'); ylabel('||AP^k-Q||_F^2');
    title('Fitting error'); legend('Location','best'); grid on;
    drawnow;
end

%% ===== Summary Table ====================================================
labels = {'LSPIA','ALSPIA','MLSPIA','SaLSPIA'};
fields = {'info_ls','info_al','info_ml','info_sl'};
fprintf('\n');
fprintf('===================================================================================================\n');
fprintf('  SUMMARY TABLE (Curve Fitting)   --   E_inf = E_k at termination\n');
fprintf('---------------------------------------------------------------------------------------------------\n');
fprintf('%-6s %-14s %9s', 'Ex', '(m+1,n+1)', 'kappa');
for j = 1:numel(labels), fprintf(' | %-26s', labels{j}); end
fprintf('\n%-6s %-14s %9s', '', '', '');
for j = 1:numel(labels), fprintf(' | %6s %8s %10s', 'IT','CPU','E_inf'); end
fprintf('\n---------------------------------------------------------------------------------------------------\n');
for ic = 1:n_cfg
    r = results{ic};
    fprintf('Ex %d   (%5d,%5d) %9.1e', r.ex_id, r.m1, r.n1, r.kappa);
    for j = 1:numel(fields)
        info = r.(fields{j});
        fprintf(' | %6d %8.4f %10.2e', info.iter_count, info.cpu_time, info.Ek_history(end));
    end
    fprintf('\n');
end


%% ===== Data Generator ===================================================
function Q = generate_curve_data(ex_id, m1)
    switch ex_id
        case 1
            theta = linspace(0,2*pi,m1)';
            r = 2 + 4*cos(2*theta+pi/4) + cos(3*theta+pi/4);
            Q = [r.*cos(theta), r.*sin(theta)];
        case 2
            theta = linspace(0,2*pi,m1)';
            Q = [10*cos(theta*pi/3), 10*sin(theta*pi/3), theta*pi/3];
        case 3
            fname = salspia_data('cur_data deer');
            if exist(fname,'file')
                Q = load(fname);
                if m1 ~= size(Q,1)
                    idx = round(linspace(1,size(Q,1),m1));
                    Q   = Q(idx,:);
                end
            else
                error(['Reindeer data file not found: %s\n' ...
                    'See DATA_SOURCES.md before running Example 4.3.'], fname);
            end
        otherwise
            error('Unknown example id: %d', ex_id);
    end
end
