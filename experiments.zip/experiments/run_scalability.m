%% ========================================================================
%  run_scalability.m
%  Large-scale tensor-product surface fitting: scalability study.
%
%  Real LiDAR terrain: Maungawhau / Mt Eden high-resolution DEM
%  (860 x 600 = 516,000 elevation samples).
%
%  The control mesh is enlarged progressively while the data are fixed,
%  to measure how iteration count and CPU time scale with problem size
%  for each method.
%
%  Reuses, without modification, the tensor-product surface routines:
%    build_collocation.m, make_clamped_knots (local), select_initial_surf,
%    lspia_surf.m, alspia_surf.m, mlspia_surf.m, salspia_surf.m (= SaLSPIA).
%
%  Data file (resolved from ../data via salspia_data): maungawhau_hr.csv
%    (860 rows x 600 cols of elevations; produced from the hillshader
%     maungawhau_hr dataset.)
%
%  Outputs:
%    scalability_results/scalability_summary.csv  / .tex / .mat
%    scalability_results/scalability_cpu.png/.fig
%    scalability_results/scalability_it.png/.fig
%  ========================================================================
clear; clc; close all;

script_dir = fileparts(mfilename('fullpath'));
addpath(script_dir);
repo_dir = fileparts(script_dir);

p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

salspia_params.c     = 1e-4;
salspia_params.M     = 10;
salspia_params.delta = 1e-8;

% Control-mesh sizes to sweep (n1u = n1v).
ctrl_sizes = [41, 61, 81, 101, 121];

% Data subsampling stride: 1 uses the full grid, 2 uses every second sample, etc.
data_stride = 1;

out_dir = fullfile(repo_dir, 'results', 'scalability');
if ~exist(out_dir, 'dir'); mkdir(out_dir); end

%% ===== Load real LiDAR terrain =========================================
csv_path = salspia_data('maungawhau_hr.csv');
if ~exist(csv_path, 'file')
    error('Data file not found: %s\nPlace maungawhau_hr.csv in the data/ folder.', csv_path);
end
Z = readmatrix(csv_path);              % 860 x 600 elevation matrix
Z = Z(1:data_stride:end, 1:data_stride:end);
[m1u, m1v] = size(Z);
fprintf('Loaded terrain: %d x %d = %d data points (stride=%d)\n', ...
    m1u, m1v, m1u*m1v, data_stride);

% Parameter grids in [0,1]
u_par = linspace(0, 1, m1u)';
v_par = linspace(0, 1, m1v)';
[Ugrid, Vgrid] = ndgrid( (u_par - u_par(1))*60, (v_par - v_par(1))*43 ); % scaled planar x,y coordinates
Qx = Ugrid;
Qy = Vgrid;
Qz = Z;

%% ===== Sweep control-mesh sizes ========================================
methods = {'LSPIA','ALSPIA','MLSPIA','SaLSPIA'};
nM = numel(methods);
nS = numel(ctrl_sizes);

IT  = nan(nS, nM);
CPU = nan(nS, nM);
EI  = nan(nS, nM);
ncp = nan(nS, 1);

for is = 1:nS
    n1u = ctrl_sizes(is);  n1v = ctrl_sizes(is);
    ncp(is) = n1u * n1v;
    fprintf('\n--- control mesh %d x %d  (%d control points) ---\n', n1u, n1v, n1u*n1v);

    knots_u = make_clamped_knots(n1u, p_deg);
    knots_v = make_clamped_knots(n1v, p_deg);
    Au = build_collocation(knots_u, p_deg, u_par);
    Av = build_collocation(knots_v, p_deg, v_par);

    Q_cell  = {Qx, Qy, Qz};
    P0_cell = cell(3,1);
    for c = 1:3, P0_cell{c} = select_initial_surf(Q_cell{c}, n1u, n1v); end

    % ---- LSPIA ----
    fprintf('  LSPIA    ... ');
    [~, i_ls] = lspia_surf(Au, Av, Q_cell, P0_cell, tol_Ek, maxiter);
    IT(is,1)=i_ls.iter_count; CPU(is,1)=i_ls.cpu_time; EI(is,1)=i_ls.Ek_history(end);
    fprintf('IT=%d CPU=%.3fs E=%.2e\n', IT(is,1), CPU(is,1), EI(is,1));

    % ---- ALSPIA ----
    fprintf('  ALSPIA   ... ');
    [~, i_al] = alspia_surf(Au, Av, Q_cell, P0_cell, tol_Ek, maxiter);
    IT(is,2)=i_al.iter_count; CPU(is,2)=i_al.cpu_time; EI(is,2)=i_al.Ek_history(end);
    fprintf('IT=%d CPU=%.3fs E=%.2e\n', IT(is,2), CPU(is,2), EI(is,2));

    % ---- MLSPIA ----
    fprintf('  MLSPIA   ... ');
    [~, i_ml] = mlspia_surf(Au, Av, Q_cell, P0_cell, tol_Ek, maxiter);
    IT(is,3)=i_ml.iter_count; CPU(is,3)=i_ml.cpu_time; EI(is,3)=i_ml.Ek_history(end);
    fprintf('IT=%d CPU=%.3fs E=%.2e\n', IT(is,3), CPU(is,3), EI(is,3));

    % ---- SaLSPIA ----
    fprintf('  SaLSPIA  ... ');
    [~, i_pb] = salspia_surf(Au, Av, Q_cell, P0_cell, tol_Ek, maxiter, salspia_params);
    IT(is,4)=i_pb.iter_count; CPU(is,4)=i_pb.cpu_time; EI(is,4)=i_pb.Ek_history(end);
    fprintf('IT=%d CPU=%.3fs E=%.2e\n', IT(is,4), CPU(is,4), EI(is,4));
end

%% ===== Summary table ====================================================
fprintf('\n==================== SCALABILITY SUMMARY ====================\n');
fprintf('%-10s', 'ctrlpts');
for j=1:nM, fprintf('%18s', [methods{j} ' IT/CPU']); end
fprintf('\n');
for is=1:nS
    fprintf('%-10d', ncp(is));
    for j=1:nM
        fprintf('   %5d / %7.3f', IT(is,j), CPU(is,j));
    end
    fprintf('\n');
end

% write CSV
rows = {};
for is=1:nS
    for j=1:nM
        rows(end+1,:) = {ncp(is), ctrl_sizes(is), methods{j}, IT(is,j), CPU(is,j), EI(is,j)}; %#ok<SAGROW>
    end
end
T = cell2table(rows, 'VariableNames', {'CtrlPoints','MeshSize','Method','IT','CPU','E_inf'});
writetable(T, fullfile(out_dir,'scalability_summary.csv'));
save(fullfile(out_dir,'scalability_results.mat'), 'T','IT','CPU','EI','ncp','ctrl_sizes','methods','m1u','m1v');
write_latex_table(ctrl_sizes, ncp, methods, IT, CPU, fullfile(out_dir,'scalability_summary.tex'));

%% ===== Scaling curves (two separate figures) ===========================
colors = [0.00 0.45 0.74;    % LSPIA
          0.85 0.33 0.10;    % ALSPIA
          0.49 0.18 0.56;    % MLSPIA
          0.10 0.60 0.20];   % SaLSPIA
styles = {'-o','-s','-d','-^'};

% CPU vs control points
f1 = figure('Color','w','Position',[100 100 700 540]);
hold on;
for j=1:nM
    loglog(ncp, CPU(:,j), styles{j}, 'Color', colors(j,:), 'LineWidth',1.8,'MarkerSize',7,'DisplayName',methods{j});
end
hold off; grid on; box on; set(gca,'XScale','log','YScale','log','FontSize',12);
xlabel('Number of control points', 'FontSize',14);
ylabel('CPU time (s)', 'FontSize',14);
legend('Location','northwest','FontSize',12);
safe_export(f1, fullfile(out_dir,'scalability_cpu.png')); savefig(f1, fullfile(out_dir,'scalability_cpu.fig'));

% IT vs control points
f2 = figure('Color','w','Position',[100 100 700 540]);
hold on;
for j=1:nM
    semilogy(ncp, IT(:,j), styles{j}, 'Color', colors(j,:), 'LineWidth',1.8,'MarkerSize',7,'DisplayName',methods{j});
end
hold off; grid on; box on; set(gca,'FontSize',12);
xlabel('Number of control points', 'FontSize',14);
ylabel('Iterations to convergence', 'FontSize',14);
legend('Location','northwest','FontSize',12);
safe_export(f2, fullfile(out_dir,'scalability_it.png')); savefig(f2, fullfile(out_dir,'scalability_it.fig'));

fprintf('\nSaved scalability outputs to:\n  %s\n', out_dir);

%% ===== local helpers =====================================================
function knots = make_clamped_knots(n1, p)
n = n1 - 1; n_int = n - p;
knots = zeros(1, n1 + p + 1);
knots(1:p+1) = 0; knots(end-p:end) = 1;
if n_int > 0
    internal = linspace(0,1,n_int+2);
    knots(p+2:end-p-1) = internal(2:end-1);
end
end

function P0 = select_initial_surf(Qc, n1u, n1v)
[mu1, mv1] = size(Qc);
idx_u = round(linspace(1, mu1, n1u));
idx_v = round(linspace(1, mv1, n1v));
P0 = Qc(idx_u, idx_v);
end

function safe_export(fig, fname)
try, exportgraphics(fig, fname, 'Resolution', 300); catch, saveas(fig, fname); end
end

function write_latex_table(ctrl_sizes, ncp, methods, IT, CPU, fname)
fid = fopen(fname,'w'); if fid==-1, warning('cannot write %s',fname); return; end
nS = numel(ctrl_sizes); nM = numel(methods);
fprintf(fid, '\\begin{table}[t]\n');
fprintf(fid, '\\caption{Scalability on the high-resolution Maungawhau LiDAR terrain (860$\\times$600 data points). IT and CPU (seconds) versus the control-mesh size.}\n');
fprintf(fid, '\\label{tab:scalability}\n');
fprintf(fid, '\\begin{tabular*}{\\textwidth}{@{\\extracolsep\\fill}ll');
for j=1:nM, fprintf(fid,'cc'); end
fprintf(fid,'@{}}\n\\toprule\n');
fprintf(fid, 'Mesh & ctrl pts');
for j=1:nM, fprintf(fid, ' & \\multicolumn{2}{c}{%s}', methods{j}); end
fprintf(fid, ' \\\\\n');
fprintf(fid, '     &         ');
for j=1:nM, fprintf(fid, ' & IT & CPU'); end
fprintf(fid, ' \\\\\n\\midrule\n');
for is=1:nS
    fprintf(fid, '$%d^2$ & %d', ctrl_sizes(is), ncp(is));
    for j=1:nM
        fprintf(fid, ' & %d & %.3f', IT(is,j), CPU(is,j));
    end
    fprintf(fid, ' \\\\\n');
end
fprintf(fid, '\\botrule\n\\end{tabular*}\n');
fprintf(fid, '\\end{table}\n');
fclose(fid);
end
