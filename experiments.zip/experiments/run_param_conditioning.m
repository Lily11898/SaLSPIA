%% ========================================================================
%  run_param_conditioning.m
%  Conditioning experiment (full-rank, ill-conditioned):
%  Same uniformly-sampled data, two parameterizations:
%     (a) chord-length  -> well-conditioned  (the paper's default)
%     (b) uniform        -> ill-conditioned   (stress test)
%
%  Goal: compare how LSPIA, ALSPIA, MLSPIA and SaLSPIA respond as the
%  conditioning kappa(A'A) worsens, under two parameterizations.
%
%  Reuses, WITHOUT MODIFICATION:
%     build_collocation.m, select_initial_ctrl_pts.m,
%     lspia.m, alspia.m, mlspia.m, salspia.m
%     and the generate_curve_data() helper copied below.
%
%  IMPORTANT: this script does NOT modify the sampling of the curve.
%  The data points Q are still sampled uniformly in the curve parameter,
%  exactly as in run_curve_comparison.m. Only the *parameterization*
%  t (assignment of parameter values to the given points) is changed.
%  ========================================================================
clear; clc; close all;

%% ===== User Settings ====================================================
p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

salspia_params.c = 1e-4; salspia_params.M = 10; salspia_params.delta = 1e-8;

% Use the smaller full-rank curve examples so the experiment is quick.
% (example_id, m+1, n+1)
configs = {
    1, 15001, 3001;   % blob
    3,  1000,  288;   % reindeer
};

param_modes = {'chord', 'uniform'};   % the two parameterizations to compare

%% ===== Run ==============================================================
n_cfg = size(configs,1);
for ic = 1:n_cfg
    ex_id = configs{ic,1};  m1 = configs{ic,2};  n1 = configs{ic,3};
    n = n1-1;
    Q  = generate_curve_data(ex_id, m1);
    P0 = select_initial_ctrl_pts(Q, n);

    fprintf('\n===================================================================\n');
    fprintf(' Example %d   (m+1=%d, n+1=%d)\n', ex_id, m1, n1);
    fprintf('===================================================================\n');

    for ip = 1:numel(param_modes)
        mode = param_modes{ip};
        [t, knots] = params_knots_mode(Q, n, p_deg, mode);
        A = build_collocation(knots, p_deg, t);

        ev = sort(real(eig(A'*A)));
        ev = ev(ev > 1e-14);
        kappa = ev(end)/ev(1);

        [~, i_ls] = lspia(A, Q, P0, tol_Ek, maxiter);
        [~, i_al] = alspia(A, Q, P0, tol_Ek, maxiter);
        [~, i_ml] = mlspia(A, Q, P0, tol_Ek, maxiter);
        [~, i_pb] = salspia(A, Q, P0, tol_Ek, maxiter, salspia_params);

        fprintf('\n  Parameterization: %-7s   kappa(A''A) = %.3e\n', mode, kappa);
        fprintf('    %-8s  IT=%6d  CPU=%9.4f  E=%.2e\n','LSPIA',  i_ls.iter_count, i_ls.cpu_time, i_ls.Ek_history(end));
        fprintf('    %-8s  IT=%6d  CPU=%9.4f  E=%.2e\n','ALSPIA', i_al.iter_count, i_al.cpu_time, i_al.Ek_history(end));
        fprintf('    %-8s  IT=%6d  CPU=%9.4f  E=%.2e\n','MLSPIA', i_ml.iter_count, i_ml.cpu_time, i_ml.Ek_history(end));
        fprintf('    %-8s  IT=%6d  CPU=%9.4f  E=%.2e\n','SaLSPIA',i_pb.iter_count, i_pb.cpu_time, i_pb.Ek_history(end));
    end
end
fprintf('\nDone. Copy kappa / IT / CPU into the LaTeX table.\n');

%% ===== Parameterization switch =========================================
function [t, knots] = params_knots_mode(Q, n, p, mode)
% Returns parameters t and knot vector for a given parameterization mode.
%   mode = 'chord'   -> chord-length (Piegl-Tiller Eq. 9.5), the default
%   mode = 'uniform' -> uniform/equally-spaced parameters t_j = j/m
% The knot vector is built by averaging (Eq. 9.69) from t in both cases,
% so the only thing that changes is the parameter assignment t.
    [m1,~] = size(Q);  m = m1-1;
    switch lower(mode)
        case 'chord'
            chords = sqrt(sum(diff(Q).^2,2));
            total  = sum(chords);
            t = zeros(m1,1);
            for j = 2:m1
                t(j) = t(j-1) + chords(j-1)/total;
            end
            t(end) = 1.0;
        case 'uniform'
            t = (0:m)'/m;            % equally spaced parameters
        otherwise
            error('Unknown parameterization mode: %s', mode);
    end

    % Averaging knot vector (Piegl-Tiller Eq. 9.69), identical to make_params_knots
    n_internal = n - p;
    knots = zeros(1,(n+1)+p+1);
    knots(1:p+1)    = 0;
    knots(end-p:end)= 1;
    if n_internal > 0
        d = (m+1)/(n-p+1);
        for j = 1:n_internal
            i = floor(j*d);
            alpha = j*d - i;
            i = max(1, min(i, m1-1));   % guard index
            knots(p+1+j) = (1-alpha)*t(i) + alpha*t(i+1);
        end
    end
end

%% ===== Data generator (copied verbatim from run_curve_comparison.m) =====
function Q = generate_curve_data(ex_id, m1)
    switch ex_id
        case 1
            theta = linspace(0,2*pi,m1)';
            r = 2 + 4*cos(2*theta+pi/4) + cos(3*theta+pi/4);
            Q = [r.*cos(theta), r.*sin(theta)];
        case 2
            theta = linspace(0,2*pi,m1)';
            Q = [10*cos(theta*pi/3), 10*sin(theta*pi/3), theta*pi/3];
        case 3
            fname = salspia_data('cur_data deer');
            if exist(fname,'file')
                Q = load(fname);
                if m1 ~= size(Q,1)
                    idx = round(linspace(1,size(Q,1),m1));
                    Q   = Q(idx,:);
                end
            else
    error('Reindeer data file not found: %s', fname);
           end
        otherwise
            error('Unknown example id: %d', ex_id);
    end
end