%% ========================================================================
%  plot_conv_surface_volcano.m
%  收敛曲线代表图 -- 曲面拟合 Example 4.6 (volcano, Maungawhau LiDAR)
%  纵轴: 相对梯度范数 E_k (log10);  横轴: 迭代次数 k
%  主图展示全程(LSPIA 需 ~1050 次), 内嵌放大插图展示前 ~130 次
%
%  依赖独立函数(同目录下的函数文件):
%    build_collocation.m, lspia_surf.m, alspia_surf.m,
%    mlspia_surf.m, salspia_surf.m
%  数据文件: volcano_hires_surface_data  (由 salspia_data 从 ../data 解析)
%  其余局部函数已内嵌于脚本末尾。
%  ========================================================================
clear; clc; close all;

%% ---- 参数 ----
p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

n1u = 59;   n1v = 41;          % 59 x 41 控制网 (与论文 Ex 4.6 一致)
data_file = 'volcano_hires_surface_data';

salspia_params.c = 1e-4;
salspia_params.M = 10;
salspia_params.delta = 1e-8;

%% ---- 读取火山数据 (OBJ-like: 首行网格维度, 其后 v x y z) ----
fid = fopen(salspia_data(data_file),'r');
if fid == -1, error('Cannot open file: %s', data_file); end
dims = sscanf(fgetl(fid), '%d %d');
m1u = dims(1);  m1v = dims(2);
n_verts = m1u * m1v;
coords = zeros(n_verts,3);  idx = 0;
while ~feof(fid)
    line = fgetl(fid);
    if ischar(line) && startsWith(strtrim(line),'v ')
        idx = idx + 1;
        coords(idx,:) = sscanf(line,'v %f %f %f')';
    end
end
fclose(fid);
coords = coords(1:idx,:);

Qx = reshape(coords(:,1), m1v, m1u)';
Qy = reshape(coords(:,2), m1v, m1u)';
Qz = reshape(coords(:,3), m1v, m1u)';
fprintf('Grid %dx%d, elevation %.2f-%.2f m\n', m1u, m1v, min(Qz(:)), max(Qz(:)));

%% ---- 构造 B 样条 ----
u_par = linspace(0,1,m1u);
v_par = linspace(0,1,m1v);
knots_u = make_clamped_knots(n1u, p_deg);
knots_v = make_clamped_knots(n1v, p_deg);
Au = build_collocation(knots_u, p_deg, u_par);
Av = build_collocation(knots_v, p_deg, v_par);

Q_cell  = {Qx, Qy, Qz};
P0_cell = cell(3,1);
for c = 1:3, P0_cell{c} = select_initial_surf(Q_cell{c}, n1u, n1v); end

%% ---- 运行四个方法 ----
[~, info_ls] = lspia_surf (Au, Av, Q_cell, P0_cell, tol_Ek, maxiter);
[~, info_al] = alspia_surf(Au, Av, Q_cell, P0_cell, tol_Ek, maxiter);
[~, info_ml] = mlspia_surf(Au, Av, Q_cell, P0_cell, tol_Ek, maxiter);
[~, info_sl] = salspia_surf(Au, Av, Q_cell, P0_cell, tol_Ek, maxiter, salspia_params);

fprintf('LSPIA  IT=%d\nALSPIA IT=%d\nMLSPIA IT=%d\nSaLSPIA IT=%d\n', ...
    info_ls.iter_count, info_al.iter_count, info_ml.iter_count, info_sl.iter_count);

%% ---- 颜色与标记 ----
col_ls = [0.12 0.31 0.47];
col_al = [0.75 0.00 0.00];
col_ml = [0.44 0.19 0.63];
col_sl = [0.85 0.33 0.10];
mk = @(it,nm) unique([1:max(1,floor(it/nm)):it+1, it+1]);

%% ---- 主图 ----
fig = figure('Position',[100 100 680 500],'Color','w');
ax  = axes('Parent',fig); hold(ax,'on');

semilogy(ax,0:info_ls.iter_count,info_ls.Ek_history,'-o','Color',col_ls,...
    'MarkerSize',5,'LineWidth',1.2,'MarkerFaceColor','w',...
    'MarkerIndices',mk(info_ls.iter_count,18),'DisplayName','LSPIA');
semilogy(ax,0:info_al.iter_count,info_al.Ek_history,'-s','Color',col_al,...
    'MarkerSize',5,'LineWidth',1.2,'MarkerFaceColor','w',...
    'MarkerIndices',mk(info_al.iter_count,12),'DisplayName','ALSPIA');
semilogy(ax,0:info_ml.iter_count,info_ml.Ek_history,'-d','Color',col_ml,...
    'MarkerSize',5,'LineWidth',1.2,'MarkerFaceColor','w',...
    'MarkerIndices',mk(info_ml.iter_count,12),'DisplayName','MLSPIA');
semilogy(ax,0:info_sl.iter_count,info_sl.Ek_history,'-p','Color',col_sl,...
    'MarkerSize',6,'LineWidth',1.7,'MarkerFaceColor','w',...
    'MarkerIndices',mk(info_sl.iter_count,10),'DisplayName','SaLSPIA');

yline(ax, tol_Ek, '--','Color',[.5 .5 .5],'LineWidth',0.9,'HandleVisibility','off');

set(ax,'YScale','log');
xlabel(ax,'Iteration $k$','Interpreter','latex','FontSize',12);
ylabel(ax,'Relative gradient norm $E_k$','Interpreter','latex','FontSize',12);
title(ax,'Surface fitting (Example 4.6, Maungawhau volcano LiDAR): $59\times41$ control mesh',...
    'Interpreter','latex','FontSize',11.5);
legend(ax,'Location','northeast','FontSize',10);
grid(ax,'on'); box(ax,'on');
set(ax,'FontSize',11,'GridLineStyle',':','XLim',[0 info_ls.iter_count],'Layer','top');

%% ---- 放大插图: 前 ~130 次迭代 ----
ZOOM = 130;
axin = axes('Parent',fig,'Position',[0.46 0.40 0.42 0.42]); hold(axin,'on');
plot_zoom(axin,info_ls,col_ls,'-o',5,1.2,ZOOM);
plot_zoom(axin,info_al,col_al,'-s',5,1.2,ZOOM);
plot_zoom(axin,info_ml,col_ml,'-d',5,1.2,ZOOM);
plot_zoom(axin,info_sl,col_sl,'-p',6,1.7,ZOOM);
yline(axin, tol_Ek, '--','Color',[.5 .5 .5],'LineWidth',0.8);
set(axin,'YScale','log','XLim',[0 ZOOM],'FontSize',9,'GridLineStyle',':');
grid(axin,'on'); box(axin,'on');
title(axin,'zoom: first 130 iters','FontSize',9);

%% ---- 导出 ----
print(fig,'fig_conv_surface_volcano','-dpdf','-r300','-bestfit');
print(fig,'fig_conv_surface_volcano','-dpng','-r300');
fprintf('saved: fig_conv_surface_volcano.pdf / .png\n');

%% ======================= 内嵌局部函数 =======================
function plot_zoom(ax, info, col, sty, ms, lw, ZOOM)
    n   = min(info.iter_count, ZOOM);
    k   = 0:n;
    Ek  = info.Ek_history(1:n+1);
    idx = unique([1:max(1,floor(n/10)):n+1, n+1]);
    semilogy(ax, k, Ek, sty, 'Color',col,'MarkerSize',ms,'LineWidth',lw,...
        'MarkerFaceColor','w','MarkerIndices',idx);
end

function knots = make_clamped_knots(n1, p)
    n = n1-1; n_int = n-p;
    knots = zeros(1, n1+p+1);
    knots(1:p+1) = 0;  knots(end-p:end) = 1;
    if n_int > 0
        internal = linspace(0,1,n_int+2);
        knots(p+2:end-p-1) = internal(2:end-1);
    end
end

function P0 = select_initial_surf(Qc, n1u, n1v)
    [mu1, mv1] = size(Qc);
    idx_u = round(linspace(1,mu1,n1u));
    idx_v = round(linspace(1,mv1,n1v));
    P0 = Qc(idx_u, idx_v);
end
