%% ========================================================================
%  plot_conv_surface_ex45.m
%  Reproduce manuscript Fig. 4: convergence histories for the Peaks surface
%  in Example 4.5.
%  ========================================================================
clear; clc; close all;

script_dir = fileparts(mfilename('fullpath'));
repo_dir = fileparts(script_dir);
addpath(fullfile(repo_dir, 'algorithms'));
addpath(fullfile(repo_dir, 'utils'));

p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

params.c     = 1e-4;
params.M     = 10;
params.delta = 1e-8;

m1u = 121; m1v = 121;
n1u = 41;  n1v = 41;

u_raw = linspace(-3, 3, m1u);
v_raw = linspace(-4, 4, m1v);
[T1, T2] = meshgrid(u_raw, v_raw);
T1 = T1';
T2 = T2';
Qx = T1;
Qy = T2;
Qz = 3*(1-T1).^2.*exp(-T1.^2-(T2+1).^2) ...
   - 10*(T1/5-T1.^3-T2.^5).*exp(-T1.^2-T2.^2) ...
   - (1/3)*exp(-(T1+1).^2-T2.^2);

u_par = linspace(0, 1, m1u);
v_par = linspace(0, 1, m1v);
Au = build_collocation(make_clamped_knots(n1u, p_deg), p_deg, u_par);
Av = build_collocation(make_clamped_knots(n1v, p_deg), p_deg, v_par);

Q = {Qx, Qy, Qz};
P0 = cell(3, 1);
for c = 1:3
    P0{c} = select_initial_surf(Q{c}, n1u, n1v);
end

[~, info_ls] = lspia_surf(Au, Av, Q, P0, tol_Ek, maxiter);
[~, info_al] = alspia_surf(Au, Av, Q, P0, tol_Ek, maxiter);
[~, info_ml] = mlspia_surf(Au, Av, Q, P0, tol_Ek, maxiter);
[~, info_sl] = salspia_surf(Au, Av, Q, P0, tol_Ek, maxiter, params);

fprintf('LSPIA IT=%d, ALSPIA IT=%d, MLSPIA IT=%d, SaLSPIA IT=%d\n', ...
    info_ls.iter_count, info_al.iter_count, info_ml.iter_count, info_sl.iter_count);

fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 680 500]);
ax = axes('Parent', fig);
hold(ax, 'on');
plot_history(ax, info_ls, '-o', [0.12 0.31 0.47], 18, 'LSPIA');
plot_history(ax, info_al, '-s', [0.75 0.00 0.00], 12, 'ALSPIA');
plot_history(ax, info_ml, '-d', [0.44 0.19 0.63], 12, 'MLSPIA');
plot_history(ax, info_sl, '-p', [0.85 0.33 0.10], 10, 'SaLSPIA');
yline(ax, tol_Ek, '--', 'Color', [0.5 0.5 0.5], 'HandleVisibility', 'off');
hold(ax, 'off');
set(ax, 'YScale', 'log', 'XLim', [0 info_ls.iter_count], ...
    'FontSize', 11, 'GridLineStyle', ':', 'Layer', 'top');
xlabel(ax, 'Iteration k');
ylabel(ax, 'Relative gradient norm E_k');
legend(ax, 'Location', 'northeast');
grid(ax, 'on');
box(ax, 'on');

zoom_ax = axes('Parent', fig, 'Position', [0.46 0.40 0.42 0.42]);
hold(zoom_ax, 'on');
plot_zoom(zoom_ax, info_ls, '-o', [0.12 0.31 0.47], 120);
plot_zoom(zoom_ax, info_al, '-s', [0.75 0.00 0.00], 120);
plot_zoom(zoom_ax, info_ml, '-d', [0.44 0.19 0.63], 120);
plot_zoom(zoom_ax, info_sl, '-p', [0.85 0.33 0.10], 120);
yline(zoom_ax, tol_Ek, '--', 'Color', [0.5 0.5 0.5]);
hold(zoom_ax, 'off');
set(zoom_ax, 'YScale', 'log', 'XLim', [0 120], 'FontSize', 9, ...
    'GridLineStyle', ':');
title(zoom_ax, 'zoom: first 120 iters', 'FontSize', 9);
grid(zoom_ax, 'on');
box(zoom_ax, 'on');

out_dir = fullfile(repo_dir, 'results', 'fig4_peaks');
if ~exist(out_dir, 'dir'), mkdir(out_dir); end
exportgraphics(fig, fullfile(out_dir, 'fig4_peaks_convergence.png'), ...
    'Resolution', 300);
exportgraphics(fig, fullfile(out_dir, 'fig4_peaks_convergence.pdf'), ...
    'ContentType', 'vector');
close(fig);

fprintf('Saved Fig. 4 outputs to:\n  %s\n', out_dir);

function plot_history(ax, info, style, color, marker_count, name)
mk = marker_indices(info.iter_count, marker_count);
semilogy(ax, 0:info.iter_count, info.Ek_history, style, ...
    'Color', color, 'MarkerSize', 5, 'LineWidth', 1.2, ...
    'MarkerFaceColor', 'w', 'MarkerIndices', mk, 'DisplayName', name);
end

function plot_zoom(ax, info, style, color, limit)
n = min(info.iter_count, limit);
mk = marker_indices(n, 10);
semilogy(ax, 0:n, info.Ek_history(1:n+1), style, ...
    'Color', color, 'MarkerSize', 4, 'LineWidth', 1.1, ...
    'MarkerFaceColor', 'w', 'MarkerIndices', mk);
end

function mk = marker_indices(it, marker_count)
mk = unique([1:max(1, floor(max(1, it) / marker_count)):it+1, it+1]);
end

function knots = make_clamped_knots(n1, p)
n = n1 - 1;
n_int = n - p;
knots = zeros(1, n1 + p + 1);
knots(1:p+1) = 0;
knots(end-p:end) = 1;
if n_int > 0
    internal = linspace(0, 1, n_int + 2);
    knots(p+2:end-p-1) = internal(2:end-1);
end
end

function P0 = select_initial_surf(Qc, n1u, n1v)
[mu1, mv1] = size(Qc);
idx_u = round(linspace(1, mu1, n1u));
idx_v = round(linspace(1, mv1, n1v));
P0 = Qc(idx_u, idx_v);
end
