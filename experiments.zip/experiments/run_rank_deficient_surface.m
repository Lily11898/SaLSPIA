%% ========================================================================
%  run_rank_deficient_surface.m
%  Reproduce Table 5 and Figure 11: incomplete Peaks surface reconstruction
%  with local holes and Gaussian noise.
%
%  The tensor-product surface is fitted from only the observed grid points.
%  The collocation matrix is assembled row-by-row for the observed samples,
%  so the holes can be local 2D regions rather than complete rows/columns.
%
%  Compared methods:
%    LSPIA, LSPIA-Lin2018, ALSPIA, SaLSPIA
%
%  Outputs:
%    results/rank_deficient_surface/surface_holes_summary.csv
%    results/rank_deficient_surface/surface_holes_summary.tex
%    results/rank_deficient_surface/surface_holes_results.mat
%    results/rank_deficient_surface/surface_holes_convergence.png/.fig
%    results/rank_deficient_surface/surface_holes_visual.png/.fig
%    results/rank_deficient_surface/surface_holes_error.png/.fig
%  ========================================================================
clear; clc; close all;

script_dir = fileparts(mfilename('fullpath'));
repo_dir = fileparts(script_dir);
addpath(fullfile(repo_dir, 'algorithms'));
addpath(fullfile(repo_dir, 'utils'));

rng(202607, 'twister');

p_deg   = 3;
tol_Ek  = 1e-6;
maxiter = 10000;

m1u = 101;
m1v = 101;
n1u = 35;
n1v = 35;

params.c           = 1e-4;
params.M           = 10;
params.delta       = 1e-8;
params.p           = 3;
params.e_tol       = 1e-15;
params.max_halving = 100;
params.mode        = 'salspia';

out_dir = fullfile(repo_dir, 'results', 'rank_deficient_surface');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

fprintf('\n============================================================\n');
fprintf('Challenging surface case: local holes on Peaks surface\n');
fprintf('============================================================\n');

%% ===== Generate Peaks surface with local holes =========================
[Qx_clean, Qy_clean, Qz_clean, u_par, v_par] = generate_peaks_surface(m1u, m1v);
Qz_data = Qz_clean;

z_range = max(Qz_clean(:)) - min(Qz_clean(:));
noise_sigma = 0.003 * z_range;
Qz_data = Qz_data + noise_sigma * randn(size(Qz_data));

[Ugrid, Vgrid] = ndgrid(u_par, v_par);
hole_mask = false(m1u, m1v);
hole_mask = hole_mask | (((Ugrid - 0.33) / 0.12).^2 + ((Vgrid - 0.42) / 0.16).^2 <= 1);
hole_mask = hole_mask | (((Ugrid - 0.70) / 0.10).^2 + ((Vgrid - 0.68) / 0.12).^2 <= 1);
hole_mask = hole_mask | (Ugrid > 0.47 & Ugrid < 0.58 & Vgrid > 0.16 & Vgrid < 0.30);
obs_mask = ~hole_mask;

knots_u = make_clamped_knots(n1u, p_deg);
knots_v = make_clamped_knots(n1v, p_deg);
Au = build_collocation(knots_u, p_deg, u_par);
Av = build_collocation(knots_v, p_deg, v_par);

[A_obs, obs_iu, obs_iv] = build_observed_surface_collocation(Au, Av, obs_mask);
Q_obs = [Qx_clean(obs_mask), Qy_clean(obs_mask), Qz_data(obs_mask)];
rankA = rank(A_obs);

P0x = select_initial_surf(Qx_clean, n1u, n1v);
P0y = select_initial_surf(Qy_clean, n1u, n1v);
P0z = select_initial_surf(Qz_data,  n1u, n1v);
P0 = [P0x(:), P0y(:), P0z(:)];

fprintf('  Grid: %d x %d, control mesh: %d x %d\n', m1u, m1v, n1u, n1v);
fprintf('  Observed points: %d, missing points: %d, rank = %d\n', ...
    size(Q_obs, 1), nnz(hole_mask), rankA);
fprintf('  Noise sigma in z: %.3e\n', noise_sigma);

%% ===== Run methods ======================================================
methods = {
    'LSPIA',          'lspia';
    'LSPIA-Lin2018',  'lin2018';
    'ALSPIA',         'alspia';
    'SaLSPIA',        'salspia';
};

summary_rows = {};
results = struct();

for im = 1:size(methods, 1)
    method_name = methods{im, 1};
    method_key  = methods{im, 2};

    fprintf('  %-8s ... ', method_name);
    switch method_key
        case 'lspia'
            [P, info] = lspia(A_obs, Q_obs, P0, tol_Ek, maxiter);
        case 'lin2018'
            [P, info] = lspia_lin2018(A_obs, Q_obs, P0, tol_Ek, maxiter);
        case 'alspia'
            [P, info] = alspia(A_obs, Q_obs, P0, tol_Ek, maxiter);
        case 'salspia'
            [P, info] = ablation_lspia(A_obs, Q_obs, P0, tol_Ek, maxiter, params);
    end

    status = get_status(info, tol_Ek, maxiter);
    rmse = surface_rmse(P, Qx_clean, Qy_clean, Qz_clean, Au, Av, n1u, n1v);
    fprintf('IT=%d  CPU=%.4fs  E=%.2e  RMSE=%.4e  status=%s\n', ...
        info.iter_count, info.cpu_time, info.Ek_history(end), rmse, status);

    results.(method_key).P = P;
    results.(method_key).info = info;
    results.(method_key).rmse = rmse;
    results.(method_key).status = status;

    summary_rows(end+1, :) = {'Peaks surface with local holes', method_name, ...
        size(Q_obs, 1), nnz(hole_mask), n1u, n1v, info.iter_count, ...
        info.cpu_time, info.Ek_history(end), info.err_history(end), rmse, status}; %#ok<SAGROW>
end

T = cell2table(summary_rows, 'VariableNames', ...
    {'Case', 'Method', 'ObservedPoints', 'MissingPoints', 'CtrlU', 'CtrlV', ...
     'IT', 'CPU', 'E_inf', 'FittingError', 'RMSE', 'Status'});

writetable(T, fullfile(out_dir, 'surface_holes_summary.csv'));
write_latex_table(T, fullfile(out_dir, 'surface_holes_summary.tex'));
save(fullfile(out_dir, 'surface_holes_results.mat'), ...
    'T', 'results', 'methods', 'Qx_clean', 'Qy_clean', 'Qz_clean', ...
    'Qz_data', 'obs_mask', 'hole_mask', 'A_obs', 'Q_obs', 'P0', ...
    'Au', 'Av', 'u_par', 'v_par', 'knots_u', 'knots_v', 'params', ...
    'noise_sigma', 'rankA');

disp(T);

plot_convergence(results, methods, tol_Ek, out_dir);
plot_surface_visual(Qx_clean, Qy_clean, Qz_clean, Qz_data, obs_mask, ...
    hole_mask, results.salspia.P, Au, Av, n1u, n1v, out_dir);
plot_surface_error(Qx_clean, Qy_clean, Qz_clean, obs_mask, ...
    results.salspia.P, Au, Av, n1u, n1v, out_dir);

fprintf('\nSaved surface holes outputs to:\n  %s\n', out_dir);

%% ===== Helpers ==========================================================
function [Qx, Qy, Qz, u_par, v_par] = generate_peaks_surface(m1u, m1v)
u_raw = linspace(-3, 3, m1u);
v_raw = linspace(-4, 4, m1v);
[T1, T2] = meshgrid(u_raw, v_raw);
T1 = T1';
T2 = T2';
Qz = 3*(1 - T1).^2 .* exp(-T1.^2 - (T2 + 1).^2) ...
    - 10*(T1/5 - T1.^3 - T2.^5) .* exp(-T1.^2 - T2.^2) ...
    - (1/3) * exp(-(T1 + 1).^2 - T2.^2);
Qx = T1;
Qy = T2;
u_par = (u_raw(:) - u_raw(1)) / (u_raw(end) - u_raw(1));
v_par = (v_raw(:) - v_raw(1)) / (v_raw(end) - v_raw(1));
end

function knots = make_clamped_knots(n1, p)
n = n1 - 1;
n_int = n - p;
knots = zeros(1, n1 + p + 1);
knots(1:p+1) = 0;
knots(end-p:end) = 1;
if n_int > 0
    internal = linspace(0, 1, n_int + 2);
    knots(p+2:end-p-1) = internal(2:end-1);
end
end

function P0 = select_initial_surf(Qc, n1u, n1v)
[mu1, mv1] = size(Qc);
idx_u = round(linspace(1, mu1, n1u));
idx_v = round(linspace(1, mv1, n1v));
P0 = Qc(idx_u, idx_v);
end

function [A_obs, obs_iu, obs_iv] = build_observed_surface_collocation(Au, Av, obs_mask)
[obs_iu, obs_iv] = find(obs_mask);
n_obs = numel(obs_iu);
n_ctrl = size(Au, 2) * size(Av, 2);
A_obs = zeros(n_obs, n_ctrl);
for k = 1:n_obs
    A_obs(k, :) = kron(Av(obs_iv(k), :), Au(obs_iu(k), :));
end
end

function [Sx, Sy, Sz] = evaluate_surface_from_vector(P, Au, Av, n1u, n1v)
Px = reshape(P(:, 1), n1u, n1v);
Py = reshape(P(:, 2), n1u, n1v);
Pz = reshape(P(:, 3), n1u, n1v);
Sx = Au * Px * Av';
Sy = Au * Py * Av';
Sz = Au * Pz * Av';
end

function rmse = surface_rmse(P, Qx, Qy, Qz, Au, Av, n1u, n1v)
[Sx, Sy, Sz] = evaluate_surface_from_vector(P, Au, Av, n1u, n1v);
residual_sq = (Sx - Qx).^2 + (Sy - Qy).^2 + (Sz - Qz).^2;
rmse = sqrt(mean(residual_sq(:)));
end

function status = get_status(info, tol_Ek, maxiter)
if isfield(info, 'status')
    status = info.status;
elseif info.Ek_history(end) < tol_Ek
    status = 'converged';
elseif info.iter_count >= maxiter
    status = 'maxiter';
else
    status = 'stopped';
end
end

function plot_convergence(results, methods, tol_Ek, out_dir)
fig = figure('Name', 'Surface holes convergence', ...
    'Color', 'w', 'Position', [100 100 760 520]);
styles = {'-o', '-s', '-d', '-^'};
colors = [0.00 0.45 0.74; 0.85 0.33 0.10; 0.49 0.18 0.56; 0.10 0.60 0.20];
hold on;
for im = 1:size(methods, 1)
    method_name = methods{im, 1};
    method_key  = methods{im, 2};
    info = results.(method_key).info;
    y = info.Ek_history;
    y(~isfinite(y) | y <= 0) = realmin;
    mk = 1:max(1, floor(info.iter_count / 15)):info.iter_count + 1;
    semilogy(0:info.iter_count, y, styles{im}, ...
        'Color', colors(im, :), 'LineWidth', 1.4, 'MarkerSize', 4, ...
        'MarkerIndices', mk, 'DisplayName', method_name);
end
yline(tol_Ek, '--', 'Color', [0.45 0.45 0.45], 'HandleVisibility', 'off');
hold off;
grid on;
xlabel('Iteration k');
ylabel('Relative gradient norm E_k');
title('Convergence on surface data with local holes');
legend('Location', 'best');

base = fullfile(out_dir, 'surface_holes_convergence');
safe_export(fig, [base '.png']);
savefig(fig, [base '.fig']);
end

function plot_surface_visual(Qx, Qy, Qz_clean, Qz_data, obs_mask, ...
    hole_mask, P, Au, Av, n1u, n1v, out_dir)
[Sx, Sy, Sz] = evaluate_surface_from_vector(P, Au, Av, n1u, n1v);

fig = figure('Name', 'Surface holes visual comparison', ...
    'Color', 'w', 'Position', [100 100 1120 820]);

subplot(2,2,1);
scatter3(Qx(obs_mask), Qy(obs_mask), Qz_data(obs_mask), 8, ...
    [0.25 0.45 0.80], 'filled');
hold on;
scatter3(Qx(hole_mask), Qy(hole_mask), Qz_clean(hole_mask), 12, ...
    [0.85 0.15 0.10], 'filled');
hold off;
axis tight; grid on; view(42, 28);
title('Input data with local holes');
xlabel('x'); ylabel('y'); zlabel('z');

subplot(2,2,2);
surf(Qx, Qy, Qz_clean, 'EdgeColor', 'none');
axis tight; grid on; view(42, 28);
title('Clean reference surface');
xlabel('x'); ylabel('y'); zlabel('z');

subplot(2,2,3);
surf(Sx, Sy, Sz, 'EdgeColor', 'none');
axis tight; grid on; view(42, 28);
title('SaLSPIA reconstructed surface');
xlabel('x'); ylabel('y'); zlabel('z');

subplot(2,2,4);
imagesc(hole_mask');
axis image; set(gca, 'YDir', 'normal');
colormap(gca, [0.85 0.85 0.85; 0.85 0.15 0.10]);
title('Missing-region mask');
xlabel('u-index'); ylabel('v-index');

base = fullfile(out_dir, 'surface_holes_visual');
safe_export(fig, [base '.png']);
savefig(fig, [base '.fig']);
end

function plot_surface_error(Qx, Qy, Qz, obs_mask, P, Au, Av, n1u, n1v, out_dir)
[Sx, Sy, Sz] = evaluate_surface_from_vector(P, Au, Av, n1u, n1v);
err = sqrt((Sx - Qx).^2 + (Sy - Qy).^2 + (Sz - Qz).^2);

fig = figure('Name', 'Surface holes error distribution', ...
    'Color', 'w', 'Position', [100 100 920 680]);
surf(Qx, Qy, Qz, err, 'EdgeColor', 'none');
hold on;
scatter3(Qx(~obs_mask), Qy(~obs_mask), Qz(~obs_mask), 14, ...
    [0.85 0.10 0.10], 'filled');
hold off;
axis tight; grid on; view(42, 28);
colorbar;
title('SaLSPIA reconstruction error relative to the clean surface');
xlabel('x'); ylabel('y'); zlabel('z');

base = fullfile(out_dir, 'surface_holes_error');
safe_export(fig, [base '.png']);
savefig(fig, [base '.fig']);
end

function write_latex_table(T, fname)
fid = fopen(fname, 'w');
if fid == -1
    warning('Cannot write LaTeX table: %s', fname);
    return;
end
fprintf(fid, '\\begin{table}[t]\n');
fprintf(fid, '\\caption{Challenging surface reconstruction with local holes.}\n');
fprintf(fid, '\\label{tab:surface_holes}\n');
fprintf(fid, '\\begin{tabular*}{\\textwidth}{@{\\extracolsep\\fill}llcccc@{}}\n');
fprintf(fid, '\\toprule\n');
fprintf(fid, 'Method &  & LSPIA & LSPIA-Lin2018 & ALSPIA & SaLSPIA \\\\\n');
fprintf(fid, '\\midrule\n');
fprintf(fid, '& $E_\\infty$');
for i = 1:height(T)
    fprintf(fid, ' & %s', sci_tex(T.E_inf(i)));
end
fprintf(fid, ' \\\\\n');
fprintf(fid, '& IT');
for i = 1:height(T)
    fprintf(fid, ' & %d', T.IT(i));
end
fprintf(fid, ' \\\\\n');
fprintf(fid, '& CPU');
for i = 1:height(T)
    fprintf(fid, ' & %.4f', T.CPU(i));
end
fprintf(fid, ' \\\\\n');
fprintf(fid, '& Status');
for i = 1:height(T)
    fprintf(fid, ' & %s', T.Status{i});
end
fprintf(fid, ' \\\\\n');
fprintf(fid, '\\botrule\n');
fprintf(fid, '\\end{tabular*}\n');
fprintf(fid, '\\end{table}\n');
fclose(fid);
end

function s = sci_tex(x)
if isinf(x)
    s = '$\infty$';
elseif isnan(x)
    s = '--';
elseif x == 0
    s = '$0$';
else
    exponent = floor(log10(abs(x)));
    mantissa = x / 10^exponent;
    s = sprintf('$%.2f\\times10^{%d}$', mantissa, exponent);
end
end

function safe_export(fig, fname)
try
    exportgraphics(fig, fname, 'Resolution', 300);
catch
    saveas(fig, fname);
end
end
