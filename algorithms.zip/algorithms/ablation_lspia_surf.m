function [P, info] = ablation_lspia_surf(Au, Av, Q, P0, tol, maxiter, params)
% ABLATION_LSPIA_SURF  Surface-fitting ablation variants for SaLSPIA.
%
%   Modes are the same as ablation_lspia.m:
%       'bb1', 'bb2', 'interp-only', 'salspia'
%
%   Q and P0 are cell arrays for coordinate components. Inner products and
%   norms are aggregated over all coordinates, matching the tensor-product
%   surface formulation in the revised manuscript.

if nargin < 5 || isempty(tol),     tol = 1e-6; end
if nargin < 6 || isempty(maxiter), maxiter = 10000; end
if nargin < 7 || isempty(params),  params = struct(); end

mode = lower(strrep(gfd(params, 'mode', 'salspia'), '_', '-'));
sigma       = gfd(params, 'c', 1e-4);
M           = gfd(params, 'M', 10);
delta       = gfd(params, 'delta', gfd(params, 'eps_m', 1e-8));
p_thr       = gfd(params, 'p', 3);
e_tol       = gfd(params, 'e_tol', 1e-15);
max_halving = gfd(params, 'max_halving', 100);

use_line_search = true;
if strcmp(mode, 'interp-only')
    use_line_search = false;
end

d = length(Q);
CH = max(sum(Au, 1)) * max(sum(Av, 1));
if CH <= 0
    error('The surface spectral upper bound C_H must be positive.');
end

P = P0;
[R, G, g_norm2, e_val] = compute_all(Au, Av, P, Q);
g0_norm2 = g_norm2;
f_val = 0.5 * e_val;

F_queue = f_val;
nc = 0;
n_updates = 0;
status = 'maxiter';

err_hist       = nan(maxiter + 1, 1);
Ek_hist        = nan(maxiter + 1, 1);
alpha_hist     = nan(maxiter, 1);
trial_hist     = nan(maxiter, 1);
bb1_hist       = nan(maxiter, 1);
bb2_hist       = nan(maxiter, 1);
mu_hist        = nan(maxiter, 1);
m_hist         = nan(maxiter, 1);
halv_hist      = zeros(maxiter, 1);

err_hist(1) = e_val;
Ek_hist(1) = initial_Ek(g0_norm2);

P_prev = P;
G_prev = G;
e_prev = e_val;

tic;
for k = 0:maxiter-1
    if k >= 1
        if ~isfinite(e_val) || ~isfinite(g_norm2)
            status = 'failed';
            break;
        end

        if abs(e_val - e_prev) < e_tol
            nc = nc + 1;
        else
            nc = 0;
        end

        Ek_cur = safe_ratio(g_norm2, g0_norm2);
        if g0_norm2 > 0 && Ek_cur < tol
            status = 'converged';
            break;
        end
        if nc >= p_thr
            status = 'stagnated';
            break;
        end
    end

    if k == 0
        alpha_hat = 1.0 / CH;
        step_stats = empty_step_stats();
    else
        [a, b, c] = aggregate_sy(P, P_prev, G, G_prev);
        [alpha_hat, step_stats] = choose_trial_step_from_abc(a, b, c, CH, delta, mode);
    end

    if ~isfinite(alpha_hat) || alpha_hat <= 0
        alpha_hat = 1.0 / CH;
        step_stats.used_fallback = true;
    end

    AG = cell(d, 1);
    for j = 1:d
        AG{j} = Au * G{j} * Av';
    end

    alpha = alpha_hat;
    n_halv = 0;

    if use_line_search
        Fk = max(F_queue);
        while true
            f_trial = 0;
            for j = 1:d
                Rt = R{j} - alpha * AG{j};
                f_trial = f_trial + norm(Rt, 'fro')^2;
            end
            f_trial = 0.5 * f_trial;

            if isfinite(f_trial) && f_trial <= Fk - sigma * alpha * g_norm2
                break;
            end

            alpha = alpha / 2.0;
            n_halv = n_halv + 1;
            if n_halv >= max_halving
                status = 'line-search-limit';
                break;
            end
        end
    end

    P_prev = P;
    G_prev = G;
    e_prev = e_val;

    P_new = cell(d, 1);
    for j = 1:d
        P_new{j} = P{j} - alpha * G{j};
    end
    P = P_new;

    [R, G, g_norm2, e_val] = compute_all(Au, Av, P, Q);
    f_val = 0.5 * e_val;

    n_updates = n_updates + 1;
    err_hist(n_updates + 1) = e_val;
    Ek_hist(n_updates + 1) = safe_ratio(g_norm2, g0_norm2);
    alpha_hist(n_updates) = alpha;
    trial_hist(n_updates) = alpha_hat;
    bb1_hist(n_updates) = step_stats.alpha_bb1;
    bb2_hist(n_updates) = step_stats.alpha_bb2;
    mu_hist(n_updates) = step_stats.mu_hat;
    m_hist(n_updates) = step_stats.m;
    halv_hist(n_updates) = n_halv;

    if length(F_queue) < M
        F_queue = [F_queue; f_val];
    else
        F_queue = [F_queue(2:end); f_val];
    end

    if strcmp(status, 'line-search-limit')
        break;
    end
end
cpu = toc;

if strcmp(status, 'maxiter') && n_updates < maxiter
    status = 'stopped';
end

info.mode          = mode;
info.iter_count    = n_updates;
info.err_history   = err_hist(1:n_updates + 1);
info.Ek_history    = Ek_hist(1:n_updates + 1);
info.alpha_history = alpha_hist(1:n_updates);
info.trial_alpha   = trial_hist(1:n_updates);
info.alpha_BB1     = bb1_hist(1:n_updates);
info.alpha_BB2     = bb2_hist(1:n_updates);
info.mu_history    = mu_hist(1:n_updates);
info.m_history     = m_hist(1:n_updates);
info.halvings      = halv_hist(1:n_updates);
info.total_halving = sum(halv_hist(1:n_updates));
info.cpu_time      = cpu;
info.CH            = CH;
info.status        = status;
info.line_search   = use_line_search;
end

function [R, G, g_norm2, e_val] = compute_all(Au, Av, P, Q)
d = length(Q);
R = cell(d, 1);
G = cell(d, 1);
g_norm2 = 0;
e_val = 0;
for j = 1:d
    R{j} = Au * P{j} * Av' - Q{j};
    G{j} = Au' * R{j} * Av;
    g_norm2 = g_norm2 + norm(G{j}, 'fro')^2;
    e_val = e_val + norm(R{j}, 'fro')^2;
end
end

function [a, b, c] = aggregate_sy(P, P_prev, G, G_prev)
d = length(P);
a = 0;
b = 0;
c = 0;
for j = 1:d
    S = P{j} - P_prev{j};
    Y = G{j} - G_prev{j};
    a = a + norm(S, 'fro')^2;
    b = b + sum(S(:) .* Y(:));
    c = c + norm(Y, 'fro')^2;
end
end

function [alpha_hat, stats] = choose_trial_step_from_abc(a, b, c, CH, delta, mode)
stats = empty_step_stats();

if a <= 0 || b <= 0 || c <= 0
    alpha_hat = 1.0 / CH;
    stats.used_fallback = true;
    return;
end

alpha_bb1 = a / b;
alpha_bb2 = b / c;

mu = b / (CH * a);
mu_hat = min(max(mu, 0), 1);
m = max(1.0 - mu_hat, delta);

switch mode
    case 'bb1'
        alpha_hat = alpha_bb1;
    case 'bb2'
        alpha_hat = alpha_bb2;
    case {'interp-only', 'salspia', 'full'}
        if 1.0 - mu_hat <= delta
            alpha_hat = alpha_bb2;
        else
            term = (2.0 * m - 1.0) * b;
            disc = term^2 + 4.0 * m * (1.0 - m) * a * c;
            denom = term + sqrt(max(disc, 0));
            if denom <= 0
                alpha_hat = alpha_bb2;
                stats.used_fallback = true;
            else
                alpha_hat = 2.0 * m * a / denom;
            end
        end
    otherwise
        error('Unknown ablation mode: %s', mode);
end

stats.alpha_bb1 = alpha_bb1;
stats.alpha_bb2 = alpha_bb2;
stats.mu = mu;
stats.mu_hat = mu_hat;
stats.m = m;
end

function stats = empty_step_stats()
stats.alpha_bb1 = NaN;
stats.alpha_bb2 = NaN;
stats.mu = NaN;
stats.mu_hat = NaN;
stats.m = NaN;
stats.used_fallback = false;
end

function y = safe_ratio(a, b)
if b > 0
    y = a / b;
else
    y = 0;
end
end

function y = initial_Ek(g0_norm2)
if g0_norm2 > 0
    y = 1.0;
else
    y = 0.0;
end
end

function v = gfd(s, f, d)
if isfield(s, f)
    v = s.(f);
else
    v = d;
end
end
